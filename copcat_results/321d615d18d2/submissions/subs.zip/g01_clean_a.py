class Stack:
    def push(self): pass

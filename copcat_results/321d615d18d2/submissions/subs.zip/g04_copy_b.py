class Employee:
    def __init__(self, name, ident, salary):
        self.name = name
        self.ident = ident
        self.salary = salary
    def pay(self):
        return self.salary

class Manager(Employee):
    def __init__(self, name, ident, salary, bonus):
        super().__init__(name, ident, salary)
        self.bonus = bonus
    def pay(self):
        return super().pay() + self.bonus

class Developer(Employee):
    def __init__(self, name, ident, salary, hours, rate):
        super().__init__(name, ident, salary)
        self.hours = hours
        self.rate = rate
    def pay(self):
        return super().pay() + self.hours * self.rate

staff = [Manager('a', 1, 10, 2), Developer('b', 2, 10, 3, 4)]
for m in staff:
    print(m.name, m.pay())

# twin

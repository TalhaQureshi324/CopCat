class Pile:
    def add(self): pass

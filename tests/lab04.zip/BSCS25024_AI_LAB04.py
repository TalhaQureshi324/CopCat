# Task 1a

def node_to_index(node):
    return ord(node) - 65

def index_to_node(idx):
    return chr(65 + idx)

def build_adj_list(edge_list):
    adj = {}
    nodes = ["A", "B", "C", "D", "E", "F"]
    for i in range(len(edge_list)):
        adj[nodes[i]] = edge_list[i]
    return adj

def bfs_traversal(adj, start_node):
    visited_order = []
    visited = []
    queue = [start_node]
    visited.append(start_node)

    while len(queue) > 0:
        curr = queue[0]
        queue = queue[1:]
        visited_order.append(curr)

        neighbors = adj[curr]
        for i in range(len(neighbors)):
            neighbor = neighbors[i]
            already_visited = False
            for j in range(len(visited)):
                if visited[j] == neighbor:
                    already_visited = True
                    break
            if not already_visited:
                visited.append(neighbor)
                queue.append(neighbor)

    return visited_order


# Task 1b

def dfs_traversal(adj, start_node):
    visited_order = []
    visited = []
    stack = [start_node]

    while len(stack) > 0:
        curr = stack[len(stack) - 1]
        stack = stack[:len(stack) - 1]

        already_visited = False
        for j in range(len(visited)):
            if visited[j] == curr:
                already_visited = True
                break

        if not already_visited:
            visited.append(curr)
            visited_order.append(curr)

            neighbors = adj[curr]
            for i in range(len(neighbors) - 1, -1, -1):
                neighbor = neighbors[i]
                neigh_visited = False
                for j in range(len(visited)):
                    if visited[j] == neighbor:
                        neigh_visited = True
                        break
                if not neigh_visited:
                    stack.append(neighbor)

    return visited_order


# Task 2

def get_blank_index(state):
    for i in range(4):
        if state[i] == 0:
            return i
    return -1

def is_solvable(state):
    tiles = []
    for i in range(4):
        if state[i] != 0:
            tiles.append(state[i])

    inv = 0
    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            if tiles[i] > tiles[j]:
                inv += 1

    blank_idx = get_blank_index(state)
    blank_row = blank_idx // 2
    row_from_bottom = 2 - blank_row

    return (inv + row_from_bottom) % 2 == 1

def states_equal(s1, s2):
    for i in range(4):
        if s1[i] != s2[i]:
            return False
    return True

def state_in_list(state, lst):
    for i in range(len(lst)):
        if states_equal(state, lst[i]):
            return True
    return False

def get_neighbors(state):
    blank_idx = get_blank_index(state)
    r = blank_idx // 2
    c = blank_idx % 2
    neighbors = []

    moves = [
        (-1, 0, "Up"),
        (1, 0, "Down"),
        (0, -1, "Left"),
        (0, 1, "Right")
    ]

    for i in range(4):
        dr = moves[i][0]
        dc = moves[i][1]
        move_name = moves[i][2]

        nr = r + dr
        nc = c + dc

        if nr >= 0 and nr < 2 and nc >= 0 and nc < 2:
            new_idx = nr * 2 + nc
            new_state = [state[0], state[1], state[2], state[3]]
            new_state[blank_idx] = new_state[new_idx]
            new_state[new_idx] = 0
            neighbors.append((tuple(new_state), move_name))

    return neighbors


# Task 2a:

def solve_4puzzle_bfs(start_state, goal_state):
    queue = [(start_state, [])]
    visited = [start_state]

    while len(queue) > 0:
        curr_state, path = queue[0]
        queue = queue[1:]

        if states_equal(curr_state, goal_state):
            return path

        neighbors = get_neighbors(curr_state)
        for i in range(len(neighbors)):
            next_state, move_name = neighbors[i]
            if not state_in_list(next_state, visited):
                visited.append(next_state)
                new_path = path + [(move_name, next_state)]
                queue.append((next_state, new_path))

    return None


# Task 2b:

def solve_4puzzle_dfs(start_state, goal_state):
    stack = [(start_state, [])]
    visited = [start_state]

    while len(stack) > 0:
        curr_state, path = stack[len(stack) - 1]
        stack = stack[:len(stack) - 1]

        if states_equal(curr_state, goal_state):
            return path

        neighbors = get_neighbors(curr_state)
        for i in range(len(neighbors)):
            next_state, move_name = neighbors[i]
            if not state_in_list(next_state, visited):
                visited.append(next_state)
                new_path = path + [(move_name, next_state)]
                stack.append((next_state, new_path))

    return None



def display_puzzle_state(state):
    return str(state[0]) + " " + str(state[1]) + "\n" + str(state[2]) + " " + str(state[3])

def print_solution(start_state, path):
    if path is None:
        print("No solution found.")
        return

    print("Move count: " + str(len(path)))
    print("Solution sequence:")
    print("Step 0:")
    print(display_puzzle_state(start_state))

    for step_num in range(1, len(path) + 1):
        move, state = path[step_num - 1]
        print("Step " + str(step_num) + ":")
        print(display_puzzle_state(state))
        print("Move: " + move)


if __name__ == "__main__":
    edge_list = [
        ["B", "C"],
        ["A", "D", "E"],
        ["A", "F"],
        ["B"],
        ["B"],
        ["C"]
    ]

    adj = build_adj_list(edge_list)

    print("--- TASK 1: Graph Traversals ---")
    print("BFS visit order:", bfs_traversal(adj, "A"))
    print("DFS visit order:", dfs_traversal(adj, "A"))
    print()

    initial_puzzle = (0, 3, 2, 1)
    goal_puzzle = (1, 2, 3, 0)

    print("--- TASK 2: 4-Puzzle ---")
    print("Start:")
    print(display_puzzle_state(initial_puzzle))
    print("Goal:")
    print(display_puzzle_state(goal_puzzle))
    print("Solvability test...")

    if is_solvable(initial_puzzle):
        print("Solvable. Running BFS to find the shortest path...")
        bfs_solution = solve_4puzzle_bfs(initial_puzzle, goal_puzzle)
        print_solution(initial_puzzle, bfs_solution)

        print("\nRunning DFS...")
        dfs_solution = solve_4puzzle_dfs(initial_puzzle, goal_puzzle)
        if dfs_solution is not None:
            print("DFS found a path with " + str(len(dfs_solution)) + " moves.")
    else:
        print("Unsolvable.")
#------------------- Task 1A --------------

def bfs(edge, labels, start):
    #Finding the index of 1st node 
    startIdx = 0
    for i in range(len(labels)):
        if labels[i] == start:
            startIdx = i

    visited = [False] * len(labels)   
    queue = []                        
    visited_order = []
    
    queue.append(startIdx)
    visited[startIdx] = True
    
    while len(queue) > 0:
        curr_idx = queue.pop(0)
        curr_label = labels[curr_idx]
        visited_order.append(curr_label)
        
        for neighbour_label in edge[curr_idx]:
            neighIdx = 0
            for i in range(len(labels)):
                if labels[i] == neighbour_label:
                    neighIdx = i
                
            if visited[neighIdx] == False:
                visited[neighIdx] = True
                queue.append(neighIdx)
        
    return visited_order

labels = ["A", "B", "C", "D", "E", "F"]

edge = [
["B", "C"], 
["A", "D", "E"], 
["A", "F"], 
["B"], 
["B"], 
["C"] 
]

start = "A"

result = bfs(edge, labels, start)
print("Visit Order of DFS: ", result)

        
        
        
#---------------- Task 1B ------------------

def dfs(edge, labels, start):
    startIdx = 0
    for i in range(len(labels)):
        if labels[i] == start:
            startIdx = i
            
    visited = [False] * len(labels)
    stack = []
    visited_order = []
    
    stack.append(startIdx)
    
    while len(stack) > 0:
        curr_idx = stack.pop()
        
        if visited[curr_idx] == False:
            visited[curr_idx] = True
            visited_order.append(labels[curr_idx])
            
            neighbours = edge[curr_idx]
            
            #now we have to push neighbours in reverse order so the first neighbour comes on top
            
            for i in range(len(neighbours) - 1, -1, -1):
                neighbour_label = neighbours[i]
                
                neighIdx = 0
                for j in range(len(labels)):
                    if labels[j] == neighbour_label:
                        neighIdx = j
                
                if visited[neighIdx] == False:
                    stack.append(neighIdx)
                    
    return visited_order

labels = ["A", "B", "C", "D", "E", "F"]

edge = [
["B", "C"], 
["A", "D", "E"], 
["A", "F"], 
["B"], 
["B"], 
["C"] 
]

start = "A"

result = dfs(edge, labels, start)
print("Visit Order of DFS: ", result)


#----------------- Task 2A -------------------

def count_inversions(state):
    grid = []
    
    for n in state:
        if n != 0:
            grid.append(n)
            
    inv = 0
    for i in range(len(grid)):
        for j in range(i + 1, len(grid)):
            if grid[i] > grid[j]:
                inv += 1
                
    return inv


def isSolvable(state):
    inv = count_inversions(state)
    
    blankIdx = 0
    
    for i in range(len(state)):
        if state[i] == 0:
            blankIdx = i
            
    if blankIdx == 0 or blankIdx == 1:
        row_from_bottom = 2
    else:
        row_from_bottom = 1
        
    return (inv + row_from_bottom) % 2 == 1


def getNeighbours(state):
    blankIdx = 0
    
    for i in range(len(state)):
        if state[i] == 0:
            blankIdx = i
            
    neighbours = []
    
    if blankIdx == 2 or blankIdx == 3:
        swapIdx = blankIdx - 2
        newState = list(state)    #turning the tuple(state) into list :)
        newState[blankIdx], newState[swapIdx] = newState[swapIdx], newState[blankIdx]
        neighbours.append((tuple(newState), "Up"))
        
    if blankIdx == 0 or blankIdx == 1:
        swapIdx = blankIdx + 2
        newState = list(state)    
        newState[blankIdx], newState[swapIdx] = newState[swapIdx], newState[blankIdx]
        neighbours.append((tuple(newState), "Down"))
        
    if blankIdx == 1 or blankIdx == 3:
        swapIdx = blankIdx - 1
        newState = list(state)    
        newState[blankIdx], newState[swapIdx] = newState[swapIdx], newState[blankIdx]
        neighbours.append((tuple(newState), "Left"))
        
    if blankIdx == 0 or blankIdx == 2:
        swapIdx = blankIdx + 1
        newState = list(state)    
        newState[blankIdx], newState[swapIdx] = newState[swapIdx], newState[blankIdx]
        neighbours.append((tuple(newState), "Right"))
        
    return neighbours

def bfs_puzzle(start_state, goal_state):
    visited = []
    visited.append(start_state)
    
    queue = []
    queue.append([start_state, []])  #[state, pathofMoves]
    
    while len(queue) > 0:
        front = queue.pop(0)
        currState = front[0]
        path = front[1]
        
        if currState == goal_state:
            return path
        
        neighbours = getNeighbours(currState)
        
        for n in neighbours:
            nextState = n[0]
            move = n[1]
            
            if nextState not in visited:
                visited.append(nextState)
                
                newPath = path +[[nextState, move]]
                
                queue.append([nextState, newPath])
                
    return None #solution not found error 404


def printState(state):
    print(state[0], state[1])
    print(state[2], state[3])
    
start = (0,3,2,1)
goal = (1,2,3,0)

print("Start: ")
printState(start)
print("Goal")
printState(goal)


if isSolvable(start):
    print("Solvable. Using BFS to find shortest path.")
    solution = bfs_puzzle(start, goal)
    
    print("Move Count: ", len(solution))
    print("Step 0: ")
    printState(start)
    
    stepNum = 1
    for state, move in solution:
        printState(state)
        print("Move", move)
        stepNum = stepNum + 1
else:
    print("Puzzle not solvable")
    

#------------------ Task 2B -------------------
        
def dfs_puzzle(start_state, goal_state):
    visited = []
    visited.append(start_state)
    
    stack = []
    stack.append([start_state, []])
    
    while len(stack) > 0:
        top = stack.pop()
        currState = top[0]
        path = top[1]
        
        if currState == goal_state:
            return path
        
        neighbours = getNeighbours(currState)
        
        for neighbour in neighbours:
            nextState = neighbour[0]
            move = neighbour[1]
            
            if nextState not in visited:
                visited.append(nextState)
                
                newPath = path + [[nextState, move]]
                stack.append([nextState, newPath])
                
    return None 

start = (0,3,2,1)
goal = (1,2,3,0)

print("Start: ")
printState(start)
print("Goal")
printState(goal)


if isSolvable(start):
    print("Solvable. Using DFS to find path...")
    solution = dfs_puzzle(start, goal)
    
    print("Move Count: ", len(solution))
    print("Step 0: ")
    printState(start)
    
    for step in solution:
        state = step[0]
        move = step[1]
        printState(state)
        print("Move: ", move)
else:
    print("Puzzle not solvable")


        
    
def bfs(start):
    visit_order = []
    visited = [start]
    queue = [start]
    
    while len(queue) > 0:
        node = queue.pop(0)
        visit_order.append(node)
        for x in edge[nodes.index(node)]:
            if x not in visited:
                visited.append(x)
                queue.append(x)
                
    return visit_order

nodes = ["A", "B", "C", "D", "E", "F"]
edge = [
["B", "C"], # neighbours of A
["A", "D", "E"], # neighbours of B
["A", "F"], # neighbours of C
["B"], # neighbours of D
["B"], # neighbours of E
["C"] # neighbours of F
]

start = "A" 
print("BFS visit order:", bfs(start))

def dfs(start):
    visit_order = []
    visited = [start]
    stack = [start]

    while len(stack) > 0:
        node = stack.pop()
        visit_order.append(node)
        
        for x in reversed(edge[nodes.index(node)]):
            if x not in visited:
                visited.append(x)
                stack.append(x)

    return visit_order


nodes = ["A", "B", "C", "D", "E", "F"]

edge = [
    ["B", "C"],        # neighbours of A
    ["A", "D", "E"],   # neighbours of B
    ["A", "F"],        # neighbours of C
    ["B"],              # neighbours of D
    ["B"],              # neighbours of E
    ["C"]               # neighbours of F
]

start = "A"
print("DFS visit order:", dfs(start))

GOAL = (1, 2, 3, 0)
MOVES = {"Up": -2, "Down": 2, "Left": -1, "Right": 1}
 
 
def is_solvable(state):
    tiles = [t for t in state if t != 0]
    inv = sum(1 for i in range(3) for j in range(i + 1, 3) if tiles[i] > tiles[j])
    row_from_bottom = 2 if state.index(0) < 2 else 1
    return (inv + row_from_bottom) % 2 == 1
 
 
def valid_moves(blank):
    result = []
    if blank >= 2: result.append("Up")
    if blank < 2:  result.append("Down")
    if blank % 2 == 1: result.append("Left")
    if blank % 2 == 0: result.append("Right")
    return result
 
 
def bfs(start):
    queue = [start]
    came_from = {start: (None, None)}   # state -> (previous_state, move)
 
    while queue:
        state = queue.pop(0)
        if state == GOAL:
            break
 
        blank = state.index(0)
        for move in valid_moves(blank):
            target = blank + MOVES[move]
            new_state = list(state)
            new_state[blank], new_state[target] = new_state[target], new_state[blank]
            new_state = tuple(new_state)
 
            if new_state not in came_from:
                came_from[new_state] = (state, move)
                queue.append(new_state)
 
    # rebuild path from GOAL back to start
    path, moves, state = [], [], GOAL
    while state is not None:
        path.append(state)
        state, move = came_from[state]
        if move:
            moves.append(move)
    return path[::-1], moves[::-1]
 
 

puzzle_start = (0, 3, 2, 1)
print("Solvable:", is_solvable(puzzle_start))
 
if is_solvable(puzzle_start):
    path, moves = bfs(puzzle_start)
    print("Move count:", len(moves))
    for i, state in enumerate(path):
        print(f"\nStep {i}: {state[0]} {state[1]} / {state[2]} {state[3]}")
        if i > 0:
            print("Move:", moves[i - 1])
            
            
            
def puzzle_dfs(start):
    stack = [start]
    came_from = {start: (None, None)}   
 
    while stack:
        state = stack.pop()            
        if state == GOAL:
            break
 
        blank = state.index(0)
        for move in valid_moves(blank):
            target = blank + MOVES[move]
            new_state = list(state)
            new_state[blank], new_state[target] = new_state[target], new_state[blank]
            new_state = tuple(new_state)
 
            if new_state not in came_from:
                came_from[new_state] = (state, move)
                stack.append(new_state)
 
   
    path, moves, state = [], [], GOAL
    while state is not None:
        path.append(state)
        state, move = came_from[state]
        if move:
            moves.append(move)
    return path[::-1], moves[::-1]
 
 
if is_solvable(puzzle_start):
    path, moves = puzzle_dfs(puzzle_start)
    print("\n\nDFS Move count:", len(moves))
    for i, state in enumerate(path):
        print(f"\nStep {i}: {state[0]} {state[1]} / {state[2]} {state[3]}")
        if i > 0:
            print("Move:", moves[i - 1])
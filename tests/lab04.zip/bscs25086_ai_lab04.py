print("--- task 1a ---")
edge=[["B", "C"], # neighbours of A
["A", "D", "E"], # neighbours of B
["A", "F"], # neighbours of C
["B"], # neighbours of D
["B"], # neighbours of E
["C"] # neighbours of F
]

start="A"

def task_1a(edge,start):
    visited=[]
    arr=[start]
    while len(arr)>0:
        node = arr.pop(0)
        if node not in visited:
            visited.append(node)
            index ="ABCDEF".index(node)
            for n in edge[index]:
                if n not in visited:
                    arr.append(n)                    
    return visited                
print(task_1a(edge, "A"))

print("--- task 1b ---")

edge = [["B", "C"],
        ["A", "D", "E"],
        ["A", "F"],
        ["B"],
        ["B"],
        ["C"]]

start = "A"

def task_1b(edge, start):
    visited = []
    def dfs(node):
        if node not in visited:
            visited.append(node)
            index = "ABCDEF".index(node)
            for n in edge[index]:
                if n not in visited:
                    dfs(n)
    dfs(start)
    return visited

print(task_1b(edge, "A"))

print("--- task 2a ---")

start = (0, 3, 2, 1)
goal = (1, 2, 3, 0)

def task_2a(start):
    visited = []
    arr = [(start, [])]
    while len(arr) > 0:
        state, path = arr.pop(0)
        if state in visited:
            continue
        visited.append(state)
        if state == goal:
            return path
        blank = state.index(0)
        moves = []
        if blank>=2:
            new_state = list(state)
            new_state[blank], new_state[blank - 2] = new_state[blank - 2], new_state[blank]
            moves.append((tuple(new_state), "up"))

        if blank<2:
            new_state = list(state)
            new_state[blank], new_state[blank + 2] = new_state[blank + 2], new_state[blank]
            moves.append((tuple(new_state), "down"))

        if blank % 2 != 0:
            new_state = list(state)
            new_state[blank], new_state[blank - 1] = new_state[blank - 1], new_state[blank]
            moves.append((tuple(new_state), "left"))

        if blank % 2 == 0:
            new_state = list(state)
            new_state[blank], new_state[blank + 1] = new_state[blank + 1], new_state[blank]
            moves.append((tuple(new_state), "right"))

        for new_state, move in moves:
            if new_state not in visited:
                arr.append((new_state, path + [move]))
    return None

ans = task_2a(start)

print("solution sequence:")
for move in ans:
    print(move)
    
print("--- task 2b ---")

def task_2b(start):
    visited = []
    def dfs(state, path):
        if state in visited:
            return None
        visited.append(state)
        if state == goal:
            return path
        blank = state.index(0)
        moves = []
        if blank>=2:
            new_state = list(state)
            new_state[blank], new_state[blank - 2] = new_state[blank - 2], new_state[blank]
            moves.append((tuple(new_state), "up"))
        if blank<2:
            new_state = list(state)
            new_state[blank], new_state[blank + 2] = new_state[blank + 2], new_state[blank]
            moves.append((tuple(new_state), "down"))
        if blank % 2 != 0:
            new_state = list(state)
            new_state[blank], new_state[blank - 1] = new_state[blank - 1], new_state[blank]
            moves.append((tuple(new_state), "left"))
        if blank % 2 == 0:
            new_state = list(state)
            new_state[blank], new_state[blank + 1] = new_state[blank + 1], new_state[blank]
            moves.append((tuple(new_state), "right"))

        for new_state, move in moves:
            if new_state not in visited:
                result = dfs(new_state, path + [move])
                if result is not None:
                    return result
        return None

    return dfs(start, [])
ans = task_2b(start)

print("solution sequence:")
for move in ans:
    print(move)


#task1-a
edge = [
    ["B", "C"],
    ["A", "D", "E"],
    ["A", "F"],
    ["B"],
    ["B"],
    ["C"]
]

nodes = ["A", "B", "C", "D", "E", "F"]

start = "A"


def bfs(graph, start):
    queue = [start]
    visited = [start]

    while queue:
        current = queue.pop(0)

        print(current, end=" ")

        position = nodes.index(current)

        for neighbour in graph[position]:
            if neighbour not in visited:
                visited.append(neighbour)
                queue.append(neighbour)

bfs(edge, start)




#task1-b
edge = [
    ["B", "C"], 
    ["A", "D", "E"],    
    ["A", "F"],         
    ["B"],      
    ["B"],        
    ["C"]   
]

nodes = ["A", "B", "C", "D", "E", "F"]


def dfs(graph, start):

    stack = [start]
    visited = []

    while stack:

        current = stack.pop()

        if current not in visited:

            visited.append(current)

            position = nodes.index(current)

            for neighbour in reversed(graph[position]):

                if neighbour not in visited:
                    stack.append(neighbour)

    return visited


result = dfs(edge, "A")
print("DFS visit order:", result)



#task2-bfs and dfs version
goal = (1, 2, 3, 0)


def solvable(state):
    numbers = []

    for x in state:
        if x != 0:
            numbers.append(x)

    inv = 0

    for i in range(len(numbers)):
        for j in range(i + 1, len(numbers)):
            if numbers[i] > numbers[j]:
                inv += 1

    blank = state.index(0)

    if blank < 2:
        row_from_bottom = 2
    else:
        row_from_bottom = 1

    return (inv + row_from_bottom) % 2 == 1


def get_moves(state):
    moves = []

    blank = state.index(0)

    row = blank // 2
    col = blank % 2

    # Down
    if row < 1:
        new_state = list(state)
        new_state[blank], new_state[blank + 2] = \
            new_state[blank + 2], new_state[blank]
        moves.append((tuple(new_state), "Down"))

    # Up
    if row > 0:
        new_state = list(state)
        new_state[blank], new_state[blank - 2] = \
            new_state[blank - 2], new_state[blank]
        moves.append((tuple(new_state), "Up"))

    # Right
    if col < 1:
        new_state = list(state)
        new_state[blank], new_state[blank + 1] = \
            new_state[blank + 1], new_state[blank]
        moves.append((tuple(new_state), "Right"))

    # Left
    if col > 0:
        new_state = list(state)
        new_state[blank], new_state[blank - 1] = \
            new_state[blank - 1], new_state[blank]
        moves.append((tuple(new_state), "Left"))

    return moves


def bfs_puzzle(start):
    queue = [(start, [])]
    visited = [start]

    while queue:
        current, path = queue.pop(0)

        if current == goal:
            return path

        for next_state, move in get_moves(current):

            if next_state not in visited:
                visited.append(next_state)

                new_path = path + [(next_state, move)]
                queue.append((next_state, new_path))

    return None


def dfs_puzzle(start):
    stack = [(start, [])]
    visited = [start]

    while stack:
        current, path = stack.pop()

        if current == goal:
            return path

        for next_state, move in get_moves(current):

            if next_state not in visited:
                visited.append(next_state)

                new_path = path + [(next_state, move)]
                stack.append((next_state, new_path))

    return None


start = (0, 3, 2, 1)

if solvable(start):
    print("Solvable")

    solution = bfs_puzzle(start)

    print("BFS solution:")
    print("Move count:", len(solution))

    for state, move in solution:
        print(state, move)

    solution = dfs_puzzle(start)

    print("\nDFS solution:")
    print("Move count:", len(solution))

    for state, move in solution:
        print(state, move)

else:
    print("Not solvable")
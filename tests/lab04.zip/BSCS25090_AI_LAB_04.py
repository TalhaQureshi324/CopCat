# def bfs_traversal(edge, start):

#     nodes = ['A', 'B', 'C', 'D', 'E', 'F']
    

#     queue = [start]
#     visited = []
    
#     while queue:

#         curr = queue.pop(0)
        
#         if curr not in visited:
#             visited.append(curr)
        
#             curr_idx = nodes.index(curr)
#             neighbors = edge[curr_idx]

#             for neighbor in neighbors:
#                 if neighbor not in visited and neighbor not in queue:
#                     queue.append(neighbor)
                    
#     return visited


# edge = [
#     ["B", "C"],       # Index 0 (A)
#     ["A", "D", "E"],   # Index 1 (B)
#     ["A", "F"],        # Index 2 (C)
#     ["B"],             # Index 3 (D)
#     ["B"],             # Index 4 (E)
#     ["C"]              # Index 5 (F)
# ]

# start = "A"
# result = bfs_traversal(edge, start)

# print("BFS visit order:", result)








# def dfs_traversal(edge, start):
  
#     nodes = ['A', 'B', 'C', 'D', 'E', 'F']
    

#     stack = [start]
#     visited = []
    
#     while stack:
  
#         curr = stack.pop()
        
#         if curr not in visited:
#             visited.append(curr)
            
      
#             curr_idx = nodes.index(curr)
#             neighbors = edge[curr_idx]
            

#             for neighbor in reversed(neighbors):
#                 if neighbor not in visited:
#                     stack.append(neighbor)
                    
#     return visited


# edge = [
#     ["B", "C"],       # Index 0 (A)
#     ["A", "D", "E"],   # Index 1 (B)
#     ["A", "F"],        # Index 2 (C)
#     ["B"],             # Index 3 (D)
#     ["B"],             # Index 4 (E)
#     ["C"]              # Index 5 (F)
# ]

# start = "A"
# result = dfs_traversal(edge, start)

# print("DFS visit order:", result)










def is_solvable(st):
    lst = [x for x in st if x != 0]
    inv = 0
    
    for i in range(len(lst)):
        for j in range(i + 1, len(lst)):
            if lst[i] > lst[j]:
                inv += 1
    
    pos = st.index(0)
    row = 2 if pos < 2 else 1
    return (inv + row) % 2 == 1

def get_adj(st):
    pos = st.index(0)
    res = []
    mvs = []
    
    if pos in [2, 3]:
        mvs.append(('Up', pos - 2))
    if pos in [0, 1]:
        mvs.append(('Down', pos + 2))
    if pos in [1, 3]:
        mvs.append(('Left', pos - 1))
    if pos in [0, 2]:
        mvs.append(('Right', pos + 1))
        
    for name, idx in mvs:
        nxt = list(st)
        nxt[pos], nxt[idx] = nxt[idx], nxt[pos]
        res.append((tuple(nxt), name))
        
    return res

def solve_4puzzle_bfs(src, target=(1, 2, 3, 0)):
    
    print(f"Start:\n{src[0]} {src[1]} {src[2]} {src[3]}")
    
    print(f"Goal:\n{target[0]} {target[1]} {target[2]} {target[3]}")
    print("Solvability test...")
    
    
    if not is_solvable(src):
        print("Not Solvable.")
        return None
    
    print("Solvable. Running BFS to find the shortest path...")
    q = [(src, [])]
    vis = {src}
    
    while q:
        cur, pth = q.pop(0)
        
        if cur == target:
            print(f"Move count: {len(pth)}")
            
            print("Solution sequence:")
            print("Step 0:")
            
            print(f"{src[0]} {src[1]} {src[2]} {src[3]}")
            
            for k, (nxt, m) in enumerate(pth, 1):
                print(f"Step {k}:")
                
                print(f"{nxt[0]} {nxt[1]} {nxt[2]} {nxt[3]}")
                
                print(f"Move: {m}")
            
            return pth
        
        for nxt_st, m in get_adj(cur):
            if nxt_st not in vis:
                vis.add(nxt_st)
                q.append((nxt_st, pth + [(nxt_st, m)]))

init_st = (0, 3, 2, 1)
solve_4puzzle_bfs(init_st)


def solve_4puzzle_dfs(src, target=(1, 2, 3, 0)):
    
    if not is_solvable(src):
        
        print("Not Solvable.")
        return None
    
    stk = [(src, [])]
    vis = {src}
    
    while stk:
        cur, pth = stk.pop()
        
        if cur == target:
            print(f" DFS Solution Found! Move count: {len(pth)}")
            return pth
        
        for nxt_st, m in get_adj(cur):
            if nxt_st not in vis:
                vis.add(nxt_st)
                stk.append((nxt_st, pth + [(nxt_st, m)]))

init_st = (0, 3, 2, 1)

solve_4puzzle_dfs(init_st)




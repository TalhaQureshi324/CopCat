
def bfs(edge, start):
    index = {
    "A": 0,
    "B": 1,
    "C": 2,
    "D": 3,
    "E": 4,
    "F": 5
    }
    result = []
    visited = [start]
    queue = [start]

    while len(queue) > 0:
        current = queue.pop(0)
        result.append(current)

        neighbours = edge[index[current]]
        for neighbour in neighbours:
            if neighbour not in visited:
                visited.append(neighbour)
                queue.append(neighbour)
    
    return result

def main1():
    edge = [
    ["B", "C"],
    ["A", "D", "E"],
    ["A", "F"],
    ["B"],
    ["B"],
    ["C"]
    ]

    print(bfs(edge, "A"))

main1()
# ======================================================= #

def dfs(edge, start):
    index = {
        "A": 0,
        "B": 1,
        "C": 2,
        "D": 3,
        "E": 4,
        "F": 5
        }
    result = []
    visited = [start]
    stack = [start]

    while stack:
        current = stack.pop()
        result.append(current)

        neighbors = edge[index[current]]

        for neighbor in reversed(neighbors):
            if neighbor not in visited:
                visited.append(neighbor)
                stack.append(neighbor)

    return result

def main2():
    edge = [
    ["B", "C"],
    ["A", "D", "E"],
    ["A", "F"],
    ["B"],
    ["B"],
    ["C"]
    ]

    print(dfs(edge, "A"))

main2()

# ============================================================ #
from collections import deque


def is_solvable(state):
    tiles = []

    for tile in state:
        if tile != 0:
            tiles.append(tile)

    inversions = 0

    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            if tiles[i] > tiles[j]:
                inversions += 1

    blank_index = state.index(0)

    if blank_index < 2:
        row_from_bottom = 2
    else:
        row_from_bottom = 1

    return (inversions + row_from_bottom) % 2 == 1


def solve_puzzle(initial):
    goal = (1, 2, 3, 0)

    if not is_solvable(initial):
        return None

    queue = deque()
    queue.append((initial, []))

    visited = []
    visited.append(initial)

    while queue:
        current, path = queue.popleft()

        if current == goal:
            return path

        blank = current.index(0)

        moves = []

        if blank >= 2:
            moves.append(("Up", blank - 2))

        if blank < 2:
            moves.append(("Down", blank + 2))

        if blank % 2 == 0:
            moves.append(("Right", blank + 1))

        if blank % 2 == 1:
            moves.append(("Left", blank - 1))

        for move, new_blank in moves:
            new_state = list(current)

            new_state[blank], new_state[new_blank] = new_state[new_blank], new_state[blank]

            new_state = tuple(new_state)

            if new_state not in visited:
                visited.append(new_state)

                new_path = path + [move]

                queue.append((new_state, new_path))

    return None

def main3():
    initial = (0, 3, 2, 1)

    solution = solve_puzzle(initial)

    if solution is None:
        print("Not solvable")
    else:
        print("Solution:", solution)
        print("Number of moves:", len(solution))


main3()
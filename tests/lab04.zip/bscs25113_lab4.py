class MemoryNode:



    def __init__(self, data_payload):
        
        self.data_payload = data_payload
        
        self.next_node = None


class CustomQueue:



    def __init__(self):
        
        self.queue_head = None
        
        self.queue_tail = None

    def enqueue_item(self, item_to_add):
        
        new_node = MemoryNode(item_to_add)
        
        if self.queue_tail is None:
            
            self.queue_head = new_node
            
            self.queue_tail = new_node
            
        else:
            
            self.queue_tail.next_node = new_node
            
            self.queue_tail = new_node

    def dequeue_item(self):
        
        if self.queue_head is None:
            
            return None
            
        extracted_data = self.queue_head.data_payload
        
        self.queue_head = self.queue_head.next_node
        
        if self.queue_head is None:
            
            self.queue_tail = None
            
        return extracted_data

    def is_empty(self):
        
        return self.queue_head is None


class CustomStack:



    def __init__(self):
        
        self.stack_top = None

    def push_item(self, item_to_add):
        
        new_node = MemoryNode(item_to_add)
        
        new_node.next_node = self.stack_top
        
        self.stack_top = new_node

    def pop_item(self):
        
        if self.stack_top is None:
            
            return None
            
        extracted_data = self.stack_top.data_payload
        
        self.stack_top = self.stack_top.next_node
        
        return extracted_data

    def is_empty(self):
        
        return self.stack_top is None


def is_item_in_tuple(target_item, search_tuple):
    
    for element in search_tuple:
        
        if element == target_item:
            
            return True
            
    return False


def append_to_tuple(base_tuple, new_item):
    
    return base_tuple + (new_item,)


def run_bfs_traversal(start_node, node_names, edge_connections):
    
    bfs_queue = CustomQueue()
    
    bfs_queue.enqueue_item(start_node)
    
    visited_nodes = ()
    
    while not bfs_queue.is_empty():
        
        current_node = bfs_queue.dequeue_item()
        
        already_visited = is_item_in_tuple(current_node, visited_nodes)
        
        if not already_visited:
            
            visited_nodes = append_to_tuple(visited_nodes, current_node)
            
            node_index = -1
            
            for idx, name in enumerate(node_names):
                
                if name == current_node:
                    
                    node_index = idx
                    
                    break
                    
            if node_index != -1:
                
                node_neighbors = edge_connections[node_index]
                
                for neighbor in node_neighbors:
                    
                    neighbor_visited = is_item_in_tuple(neighbor, visited_nodes)
                    
                    if not neighbor_visited:
                        
                        bfs_queue.enqueue_item(neighbor)
                        
    return visited_nodes


def run_dfs_traversal(start_node, node_names, edge_connections):
    
    dfs_stack = CustomStack()
    
    dfs_stack.push_item(start_node)
    
    visited_nodes = ()
    
    while not dfs_stack.is_empty():
        
        current_node = dfs_stack.pop_item()
        
        already_visited = is_item_in_tuple(current_node, visited_nodes)
        
        if not already_visited:
            
            visited_nodes = append_to_tuple(visited_nodes, current_node)
            
            node_index = -1
            
            for idx, name in enumerate(node_names):
                
                if name == current_node:
                    
                    node_index = idx
                    
                    break
                    
            if node_index != -1:
                
                node_neighbors = edge_connections[node_index]
                
                reversed_neighbors = reversed(node_neighbors)
                
                for neighbor in reversed_neighbors:
                    
                    neighbor_visited = is_item_in_tuple(neighbor, visited_nodes)
                    
                    if not neighbor_visited:
                        
                        dfs_stack.push_item(neighbor)
                        
    return visited_nodes


def is_puzzle_solvable(puzzle_state):
    
    tiles_without_blank = ()
    
    for tile in puzzle_state:
        
        if tile != 0:
            
            tiles_without_blank = append_to_tuple(tiles_without_blank, tile)
            
    inversion_count = 0
    
    total_tiles = len(tiles_without_blank)
    
    for i in range(total_tiles):
        
        for j in range(i + 1, total_tiles):
            
            tile_i = tiles_without_blank[i]
            
            tile_j = tiles_without_blank[j]
            
            if tile_i > tile_j:
                
                inversion_count += 1
                
    blank_index = -1
    
    for idx, tile in enumerate(puzzle_state):
        
        if tile == 0:
            
            blank_index = idx
            
            break
            
    if blank_index in (2, 3):
        
        row_from_bottom = 1
        
    else:
        
        row_from_bottom = 2
        
    is_solvable = (inversion_count + row_from_bottom) % 2 == 1
    
    return is_solvable


def swap_tuple_elements(state_tuple, index_one, index_two):
    
    val_a, val_b, val_c, val_d = state_tuple
    
    temp_dict = {
        0: val_a, 
        1: val_b, 
        2: val_c, 
        3: val_d
    }
    
    temp_val = temp_dict[index_one]
    
    temp_dict[index_one] = temp_dict[index_two]
    
    temp_dict[index_two] = temp_val
    
    new_tuple = (
        temp_dict[0], 
        temp_dict[1], 
        temp_dict[2], 
        temp_dict[3]
    )
    
    return new_tuple


def get_valid_board_moves(current_board):
    
    blank_index = -1
    
    for idx, tile in enumerate(current_board):
        
        if tile == 0:
            
            blank_index = idx
            
            break
            
    valid_moves = ()
    
    if blank_index in (2, 3):
        
        target_idx = blank_index - 2
        
        new_board = swap_tuple_elements(current_board, blank_index, target_idx)
        
        move_info = ("Up", new_board)
        
        valid_moves = append_to_tuple(valid_moves, move_info)
        
    if blank_index in (0, 1):
        
        target_idx = blank_index + 2
        
        new_board = swap_tuple_elements(current_board, blank_index, target_idx)
        
        move_info = ("Down", new_board)
        
        valid_moves = append_to_tuple(valid_moves, move_info)
        
    if blank_index in (1, 3):
        
        target_idx = blank_index - 1
        
        new_board = swap_tuple_elements(current_board, blank_index, target_idx)
        
        move_info = ("Left", new_board)
        
        valid_moves = append_to_tuple(valid_moves, move_info)
        
    if blank_index in (0, 2):
        
        target_idx = blank_index + 1
        
        new_board = swap_tuple_elements(current_board, blank_index, target_idx)
        
        move_info = ("Right", new_board)
        
        valid_moves = append_to_tuple(valid_moves, move_info)
        
    return valid_moves


def find_shortest_bfs_path(start_state, goal_state):
    
    path_queue = CustomQueue()
    
    initial_path = ()
    
    path_queue.enqueue_item((start_state, initial_path))
    
    visited_states = ()
    
    while not path_queue.is_empty():
        
        current_state, past_moves = path_queue.dequeue_item()
        
        if current_state == goal_state:
            
            return past_moves
            
        state_visited = is_item_in_tuple(current_state, visited_states)
        
        if not state_visited:
            
            visited_states = append_to_tuple(visited_states, current_state)
            
            next_moves = get_valid_board_moves(current_state)
            
            for move_name, next_board in next_moves:
                
                next_visited = is_item_in_tuple(next_board, visited_states)
                
                if not next_visited:
                    
                    new_path = append_to_tuple(past_moves, (move_name, next_board))
                    
                    path_queue.enqueue_item((next_board, new_path))
                    
    return None


def print_puzzle_board(puzzle_state):
    
    tile_one = puzzle_state[0]
    
    tile_two = puzzle_state[1]
    
    tile_three = puzzle_state[2]
    
    tile_four = puzzle_state[3]
    
    print(f"{tile_one} {tile_two}")
    
    print(f"{tile_three} {tile_four}")

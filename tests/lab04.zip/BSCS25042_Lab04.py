def not_visited(visited_list, node):
    for item in visited_list:
        if item == node:
            return False
    return True

# TASK 1a: BFS

edge = [
    ["B", "C"],       # neighbours of A 
    ["A", "D", "E"],  # neighbours of B
    ["A", "F"],       # neighbours of C
    ["B"],            # neighbours of D
    ["B"],            # neighbours of E
    ["C"]             # neighbours of F
]

nodes = ["A", "B", "C", "D", "E", "F"]

def bfs(graph, start_node):
    queue = [start_node]
    visited = [start_node]
    
    while len(queue) > 0:
        current = queue.pop(0)
        idx = nodes.index(current)
    
        for n in graph[idx]:
            if not_visited(visited, n):
                visited.append(n)
                queue.append(n)
                
    return visited

start = "A"
bfs = bfs(edge, start)
print("BFS visit order:", bfs)
print()


# TASK 1b: DFS

def dfs(graph, current, visited=[]):
        
    visited.append(current)
    idx = nodes.index(current)
    for n in graph[idx]:
        if not_visited(visited, n):
            dfs(graph, n, visited)
            
    return visited

dfs = dfs(edge, start)
print("DFS visit order:", dfs)

# TASK 2: 4-Puzzle (2x2 Sliding Puzzle)

def print_board(state):
    print(f"{state[0]} {state[1]}")
    print(f"{state[2]} {state[3]}")

def is_solvable(state):
    tiles = []
    for t in state:
        if t != 0:
            tiles.append(t)
            
    inv = 0
    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            if tiles[i] > tiles[j]:
                inv += 1

    blank_index = state.index(0)
    if blank_index < 2:
        row_from_bottom = 2
    else:
        row_from_bottom = 1
        
    return (inv + row_from_bottom) % 2 == 1

def get_neighbours(state):
    blank_index = state.index(0)
    row = blank_index // 2
    col = blank_index % 2
    
    neighbours = []
    
    moves = [
        ("Up", row - 1, col),
        ("Down", row + 1, col),
        ("Left", row, col - 1),
        ("Right", row, col + 1)
    ]
    
    for move_name, next_row, next_col in moves:
        if 0 <= next_row < 2 and 0 <= next_col < 2:
            new_blank_index = next_row * 2 + next_col
            state_list = list(state)
            state_list[blank_index], state_list[new_blank_index] = state_list[new_blank_index], state_list[blank_index]
            neighbours.append((tuple(state_list), move_name))
            
    return neighbours

# Task 2a: BFS for 4-Puzzle

def solve_puzzle_bfs(start, goal):
    
    queue = [(start, [])]
    visited = [start]
    
    while len(queue) > 0:
        current_state, path = queue.pop(0)
        
        if current_state == goal:
            return path
            
        for next_state, move_name in get_neighbours(current_state):
            if next_state not in visited:
                visited.append(next_state)
                queue.append((next_state, path + [(next_state, move_name)]))
                
    return None


# Task 2b: DFS for 4-Puzzle
def solve_puzzle_dfs(current_state, goal, visited=None, path=None):
    if visited is None:
        visited = []
    if path is None:
        path = []
        
    visited.append(current_state)
    
    if current_state == goal:
        return path
        
    for next_state, move_name in get_neighbours(current_state):
        if next_state not in visited:
            result = solve_puzzle_dfs(next_state, goal, visited, path + [(next_state, move_name)])
            if result is not None:
                return result
                
    return None

# Running Task 2

initial_state = (0, 3, 2, 1)
goal_state = (1, 2, 3, 0)

print("=" * 45)
print("Task 2 - 4-Puzzle (2x2 sliding puzzle)")
print("=" * 45)
print("Start:")
print_board(initial_state)
print()
print("Goal:")
print_board(goal_state)
print()

print("Solvability test...")
if is_solvable(initial_state):
    print("Solvable. Running BFS to find the shortest path...")
    bfs_solution = solve_puzzle_bfs(initial_state, goal_state)
    
    if bfs_solution is not None:
        print(f"Move count: {len(bfs_solution)}")
        print()
        print("Solution sequence:")
        print()
        print("Step 0:")
        print_board(initial_state)
        print()
        
        step_num = 1
        for state, move in bfs_solution:
            print(f"Step {step_num}:")
            print_board(state)
            print(f"Move: {move}")
            print()
            step_num += 1
            
    # Task 2b: DFS Solution
    print("-" * 45)
    print("Task 2b: Running DFS to find a solution path...")
    dfs_solution = solve_puzzle_dfs(initial_state, goal_state)
    if dfs_solution is not None:
        print(f"Move count: {len(dfs_solution)}")
        print()
        print("Solution sequence (DFS):")
        print()
        print("Step 0:")
        print_board(initial_state)
        print()
        step_num = 1
        for state, move in dfs_solution:
            print(f"Step {step_num}:")
            print_board(state)
            print(f"Move: {move}")
            print()
            step_num += 1
else:
    print("The initial state is Not Solvable.")
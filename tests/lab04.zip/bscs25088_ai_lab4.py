def graph_bfs(edge, start):
    n = len(edge)
    visited = [False] * n
    order = []

    start_index = ord(start) - ord('A')
    queue = [start]
    visited[start_index] = True
    front = 0

    while front < len(queue):
        current = queue[front]
        front += 1
        order.append(current)

        current_index = ord(current) - ord('A')
        for neighbour in edge[current_index]:
            neighbour_index = ord(neighbour) - ord('A')
            if visited[neighbour_index] == False:
                visited[neighbour_index] = True
                queue.append(neighbour)

    return order


def graph_dfs(edge, start):
    n = len(edge)
    visited = [False] * n
    order = []

    def visit(node):
        index = ord(node) - ord('A')
        visited[index] = True
        order.append(node)
        for neighbour in edge[index]:
            neighbour_index = ord(neighbour) - ord('A')
            if visited[neighbour_index] == False:
                visit(neighbour)

    visit(start)
    return order


def print_board(state):
    print(state[0], state[1])
    print(state[2], state[3])


def count_inversions(state):
    tiles = [x for x in state if x != 0]
    inv = 0
    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            if tiles[i] > tiles[j]:
                inv += 1
    return inv


def is_solvable(state):
    inv = count_inversions(state)
    blank_index = state.index(0)
    row_from_top = blank_index // 2
    row_from_bottom = 2 - row_from_top
    return (inv + row_from_bottom) % 2 == 1


def get_neighbors(state):
    blank_index = state.index(0)
    row = blank_index // 2
    col = blank_index % 2

    directions = {
        "Up": (-1, 0),
        "Down": (1, 0),
        "Left": (0, -1),
        "Right": (0, 1)
    }

    neighbors = []
    for move_name, (dr, dc) in directions.items():
        new_row = row + dr
        new_col = col + dc
        if 0 <= new_row < 2 and 0 <= new_col < 2:
            new_index = new_row * 2 + new_col
            new_state = list(state)
            new_state[blank_index], new_state[new_index] = new_state[new_index], new_state[blank_index]
            neighbors.append((move_name, tuple(new_state)))
    return neighbors


def bfs_puzzle(start, goal):
    if start == goal:
        return [start], []

    visited = set()
    visited.add(start)
    queue = [start]
    front = 0
    parent = {start: (None, None)}

    while front < len(queue):
        current = queue[front]
        front += 1

        if current == goal:
            break

        for move_name, next_state in get_neighbors(current):
            if next_state not in visited:
                visited.add(next_state)
                parent[next_state] = (current, move_name)
                queue.append(next_state)

    path = []
    moves = []
    node = goal
    while node is not None:
        prev_state, move_used = parent[node]
        path.append(node)
        if move_used is not None:
            moves.append(move_used)
        node = prev_state

    path.reverse()
    moves.reverse()
    return path, moves


def dfs_puzzle(start, goal):
    if start == goal:
        return [start], []

    visited = set()
    visited.add(start)
    stack = [(start, [start], [])]

    while stack:
        current, path, moves = stack.pop()

        if current == goal:
            return path, moves

        for move_name, next_state in get_neighbors(current):
            if next_state not in visited:
                visited.add(next_state)
                stack.append((next_state, path + [next_state], moves + [move_name]))

    return None, None


def solve_puzzle(start, method="bfs"):
    goal = (1, 2, 3, 0)

    print("Start:")
    print_board(start)
    print("Goal:")
    print_board(goal)

    print("Solvability test...")
    if not is_solvable(start):
        print("Not solvable.")
        return

    if method == "bfs":
        print("Solvable. Running BFS to find the shortest path...")
        path, moves = bfs_puzzle(start, goal)
    else:
        print("Solvable. Running DFS to find a path...")
        path, moves = dfs_puzzle(start, goal)

    print("Move count:", len(moves))
    print("Solution sequence:")
    print("Step 0:")
    print_board(path[0])

    for i in range(1, len(path)):
        print(f"Step {i}:")
        print_board(path[i])
        print("Move:", moves[i - 1])


def get_graph_input():
    edge = [
        ["B", "C"],
        ["A", "D", "E"],
        ["A", "F"],
        ["B"],
        ["B"],
        ["C"]
    ]
    start = "A"
    return edge, start


def get_puzzle_input():
    print("Enter the initial state as 4 numbers (0 for blank), e.g. for")
    print("0 3")
    print("2 1")
    print("enter: 0 3 2 1")
    values = input("Initial state: ").split()
    state = tuple(int(v) for v in values)
    return state


def main():
    while True:
        print("\n===== MAIN MENU =====")
        print("1. Graph BFS")
        print("2. Graph DFS")
        print("3. 4-Puzzle using BFS")
        print("4. 4-Puzzle using DFS")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            edge, start = get_graph_input()
            result = graph_bfs(edge, start)
            print("BFS visit order:", result)

        elif choice == "2":
            edge, start = get_graph_input()
            result = graph_dfs(edge, start)
            print("DFS visit order:", result)

        elif choice == "3":
            state = get_puzzle_input()
            solve_puzzle(state, method="bfs")

        elif choice == "4":
            state = get_puzzle_input()
            solve_puzzle(state, method="dfs")

        elif choice == "5":
            print("Exiting...")
            break

        else:
            print("Invalid choice, try again.")


if __name__ == "__main__":
    main()
def bfs(edge, start):

    nodes = ["A", "B", "C", "D", "E", "F"]

    visited = []
    queue = []

    visited.append(start)
    queue.append(start)

    while len(queue) > 0:

        current = queue.pop(0)

        index = nodes.index(current)

        for neighbour in edge[index]:

            if neighbour not in visited:
                visited.append(neighbour)
                queue.append(neighbour)

    return visited


edge = [
    ["B", "C"],      
    ["A", "D", "E"],  
    ["A", "F"],       
    ["B"],          
    ["B"],           
    ["C"]            
]

start = "A"

result = bfs(edge, start)

print("BFS visit order:", result)


def dfs(edge, start):

    nodes = ["A", "B", "C", "D", "E", "F"]

    visited = []
    stack = []

    stack.append(start)

    while len(stack) > 0:

        current = stack.pop()

        if current not in visited:

            visited.append(current)

            index = nodes.index(current)

            for neighbour in reversed(edge[index]):

                if neighbour not in visited:
                    stack.append(neighbour)

    return visited


result = dfs(edge, start)

print("DFS visit order:", result)




   



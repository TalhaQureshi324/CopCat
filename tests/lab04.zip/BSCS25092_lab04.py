def get_length(sequence):
    """Calculates length without using len()."""
    count = 0
    for _ in sequence:
        count += 1
    return count

def is_in_list(target, sequence):
    """Checks membership without using the 'in' operator on sequence."""
    for item in sequence:
        if item == target:
            return True
    return False

def add_element(lst, element):
    """Appends an element to a list without using list.append()."""
    return lst + [element]

def node_to_index(node):
    """
    Maps node character to edge-list index ('A' -> 0, 'B' -> 1, ..., 'F' -> 5)
    without using .index() or dict.
    """
    nodes = ['A', 'B', 'C', 'D', 'E', 'F']
    idx = 0
    for n in nodes:
        if n == node:
            return idx
        idx += 1
    return -1

def bfs_traversal(edge, start_node):
    # Queue and visited order initialized
    queue = [start_node]
    visited = [start_node]
    head_idx = 0
    
    while head_idx < get_length(queue):
        # Dequeue
        current_node = queue[head_idx]
        head_idx += 1
        curr_idx = node_to_index(current_node)
        neighbors = edge[curr_idx]
        for neighbor in neighbors:
            if not is_in_list(neighbor, visited):
                visited = add_element(visited, neighbor)
                queue = add_element(queue, neighbor)
                
    return visited

def dfs_traversal(edge, start_node):
    stack = [start_node]
    visited = []
    
    while get_length(stack) > 0:
        stack_len = get_length(stack)
        current_node = stack[stack_len - 1]
        new_stack = []
        i = 0
        while i < stack_len - 1:
            new_stack = add_element(new_stack, stack[i])
            i += 1
        stack = new_stack
        
        if not is_in_list(current_node, visited):
            visited = add_element(visited, current_node)
            curr_idx = node_to_index(current_node)
            neighbors = edge[curr_idx]
            n_len = get_length(neighbors)
            idx = n_len - 1
            while idx >= 0:
                neighbor = neighbors[idx]
                if not is_in_list(neighbor, visited):
                    stack = add_element(stack, neighbor)
                idx -= 1
                
    return visited

edge = [
    ["B", "C"],         # index 0: neighbours of A
    ["A", "D", "E"],    # index 1: neighbours of B
    ["A", "F"],         # index 2: neighbours of C
    ["B"],              # index 3: neighbours of D
    ["B"],              # index 4: neighbours of E
    ["C"]               # index 5: neighbours of F
]
Start = "A"
bfs_order = bfs_traversal(edge, Start)
dfs_order = dfs_traversal(edge, Start)
print("BFS visit order:", bfs_order)
print("DFS visit order:", dfs_order)

def get_len(seq):
    """Calculates length without len()."""
    count = 0
    for _ in seq:
        count += 1
    return count

def add_item(lst, item):
    """Adds an element without list.append()."""
    return lst + [item]

def tuples_equal(t1, t2):
    """Compares two 4-tuples element by element."""
    i = 0
    while i < 4:
        if t1[i] != t2[i]:
            return False
        i += 1
    return True

def state_in_list(target, lst):
    """Checks if state is present in visited list without 'in' operator."""
    i = 0
    total = get_len(lst)
    while i < total:
        if tuples_equal(target, lst[i]):
            return True
        i += 1
    return False

def find_blank_index(state):
    """Finds index (0 to 3) of blank 0."""
    i = 0
    while i < 4:
        if state[i] == 0:
            return i
        i += 1
    return -1

def swap_and_create(state, i, j):
    """Creates a new state tuple swapping positions i and j."""
    temp = [state[0], state[1], state[2], state[3]]
    val = temp[i]
    temp[i] = temp[j]
    temp[j] = val
    return (temp[0], temp[1], temp[2], temp[3])

def is_solvable(state):
    """
    Solvability for 2x2:
    inv = number of inversions excluding 0
    row_from_bottom = 1 for bottom row (indices 2,3), 2 for top row (indices 0,1)
    Solvable iff: (inv + row_from_bottom) % 2 == 1
    """
    # 1. Count inversions
    inv = 0
    i = 0
    while i < 4:
        if state[i] != 0:
            j = i + 1
            while j < 4:
                if state[j] != 0 and state[i] > state[j]:
                    inv += 1
                j += 1
        i += 1
    blank_idx = find_blank_index(state)
    if blank_idx == 0 or blank_idx == 1:
        row_from_bottom = 2  # top row
    else:
        row_from_bottom = 1  # bottom row

    return (inv + row_from_bottom) % 2 == 1

def get_successors(state):
    """
    Returns valid moves in order: Down, Right, Up, Left.
    Moves correspond to sliding the blank tile.
    """
    b_idx = find_blank_index(state)
    successors = []
    if b_idx == 0 or b_idx == 1:
        new_st = swap_and_create(state, b_idx, b_idx + 2)
        successors = add_item(successors, (new_st, "Down"))
    if b_idx == 0 or b_idx == 2:
        new_st = swap_and_create(state, b_idx, b_idx + 1)
        successors = add_item(successors, (new_st, "Right"))
    if b_idx == 2 or b_idx == 3:
        new_st = swap_and_create(state, b_idx, b_idx - 2)
        successors = add_item(successors, (new_st, "Up"))
    if b_idx == 1 or b_idx == 3:
        new_st = swap_and_create(state, b_idx, b_idx - 1)
        successors = add_item(successors, (new_st, "Left"))

    return successors

def solve_4puzzle_bfs(start_state, goal_state):
    queue = [ (start_state, [(start_state, None)]) ]
    visited = [start_state]
    head = 0

    while head < get_len(queue):
        current_state, path = queue[head]
        head += 1

        if tuples_equal(current_state, goal_state):
            return path

        succs = get_successors(current_state)
        s_idx = 0
        total_s = get_len(succs)
        while s_idx < total_s:
            next_state, move = succs[s_idx]
            if not state_in_list(next_state, visited):
                visited = add_item(visited, next_state)
                new_path = add_item(path, (next_state, move))
                queue = add_item(queue, (next_state, new_path))
            s_idx += 1

    return None
def solve_4puzzle_dfs(start_state, goal_state):
    stack = [ (start_state, [(start_state, None)]) ]
    visited = []

    while get_len(stack) > 0:
        # Pop from stack
        st_len = get_len(stack)
        current_state, path = stack[st_len - 1]
        
        new_stack = []
        i = 0
        while i < st_len - 1:
            new_stack = add_item(new_stack, stack[i])
            i += 1
        stack = new_stack

        if tuples_equal(current_state, goal_state):
            return path

        if not state_in_list(current_state, visited):
            visited = add_item(visited, current_state)

            succs = get_successors(current_state)
            s_len = get_len(succs) 
            idx = s_len - 1
            while idx >= 0:
                next_state, move = succs[idx]
                if not state_in_list(next_state, visited):
                    new_path = add_item(path, (next_state, move))
                    stack = add_item(stack, (next_state, new_path))
                idx -= 1

    return None

def print_solution(path):
    move_count = get_len(path) - 1
    print(f"Move count: {move_count}")
    print("Solution sequence:")
    
    step = 0
    total_steps = get_len(path)
    while step < total_steps:
        st, move = path[step]
        print(f"Step {step}:")
        print(f"{st[0]} {st[1]}")
        print(f"{st[2]} {st[3]}")
        if move is not None:
            print(f"Move: {move}")
        step += 1
        
initial_state = (0, 3, 2, 1)
goal_state = (1, 2, 3, 0)

print("Start:")
print(f"{initial_state[0]} {initial_state[1]}")
print(f"{initial_state[2]} {initial_state[3]}")
print("Goal:")
print(f"{goal_state[0]} {goal_state[1]}")
print(f"{goal_state[2]} {goal_state[3]}")

print("Solvability test...")
if is_solvable(initial_state):
    print("Solvable. Running BFS to find the shortest path...")
    bfs_path = solve_4puzzle_bfs(initial_state, goal_state)
    print_solution(bfs_path)
    
    print("\n-------------------------------------------")
    print("Running DFS to find a solution path...")
    dfs_path = solve_4puzzle_dfs(initial_state, goal_state)
    print(f"DFS Path Length (Move count): {get_len(dfs_path) - 1}")
else:
    print("Unsolvable puzzle state.")

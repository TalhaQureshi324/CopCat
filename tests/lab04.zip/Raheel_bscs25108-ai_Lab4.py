edges = [
    ["A", "B"],
    ["A", "C"],
    ["B", "D"],
    ["B", "E"],
    ["C", "F"]
]

def bfs(edges,start):
    queue=[]
    visited=[]

    queue.append(start)

    while len(queue)>0:
        current=queue[0]
        queue=queue[1:]

        if current not in visited:
            visited.append(current)

            for edge in edges:
                if edge[0]==current:
                    neighbour=edge[1]

                    if neighbour not in visited:
                        queue.append(neighbour)

                elif edge[1]==current:
                    neighbour=edge[0]

                    if neighbour not in visited:
                        queue.append(neighbour)

    return visited


result = bfs(edges,"A")

print("BFS visit order:",result)

def dfs(edges,current,visited):

    visited.append(current)

    for edge in edges:

        if edge[0]==current:
            neighbour=edge[1]

            if neighbour not in visited:
                dfs(edges,neighbour,visited)

        elif edge[1]==current:
            neighbour=edge[0]

            if neighbour not in visited:
                dfs(edges,neighbour,visited)

    return visited

visited =[]
result = dfs(edges,"A",visited)
print("DFS visit order:",result)


# Task 2
def solvable(state):

    inversions = 0

    for i in range(4):
        for j in range(i + 1, 4):

            if state[i] != 0 and state[j] != 0:

                if state[i] > state[j]:
                    inversions = inversions + 1

    blank = 0

    for i in range(4):
        if state[i] == 0:
            blank = i

    if blank == 0 or blank == 1:
        row_from_bottom = 2
    else:
        row_from_bottom = 1

    if (inversions + row_from_bottom) % 2 == 1:
        return True
    else:
        return False
    
def make_move(state, direction):

    blank = 0

    for i in range(4):
        if state[i] == 0:
            blank = i

    new_state = [state[0], state[1], state[2], state[3]]

    if direction == "Up":

        if blank >= 2:
            temp = new_state[blank]
            new_state[blank] = new_state[blank - 2]
            new_state[blank - 2] = temp
        else:
            return None

    elif direction == "Down":

        if blank < 2:
            temp = new_state[blank]
            new_state[blank] = new_state[blank + 2]
            new_state[blank + 2] = temp
        else:
            return None

    elif direction == "Left":

        if blank == 1 or blank == 3:
            temp = new_state[blank]
            new_state[blank] = new_state[blank - 1]
            new_state[blank - 1] = temp
        else:
            return None

    elif direction == "Right":

        if blank == 0 or blank == 2:
            temp = new_state[blank]
            new_state[blank] = new_state[blank + 1]
            new_state[blank + 1] = temp
        else:
            return None

    return tuple(new_state)

def puzzle_bfs(start):

    goal = (1, 2, 3, 0)

    queue = []
    visited = []

    queue.append([start, []])

    while len(queue) > 0:

        current = queue[0]
        queue = queue[1:]

        state = current[0]
        path = current[1]

        if state == goal:
            return path

        if state in visited:
            continue

        visited.append(state)

        directions = ["Up", "Down", "Left", "Right"]

        for direction in directions:

            new_state = make_move(state, direction)

            if new_state is not None:

                if new_state not in visited:

                    new_path = path + [direction]

                    queue.append([new_state, new_path])

    return None

start = (0, 3, 2, 1)

if solvable(start):

    solution = puzzle_bfs(start)

    print("Solvable")
    print("Move count:", len(solution))
    print("Solution:", solution)

else:

    print("Not Solvable")
def puzzle_dfs(state, goal, visited, path):

    if state == goal:
        return path

    visited.append(state)

    directions = ["Up", "Down", "Left", "Right"]

    for direction in directions:

        new_state = make_move(state, direction)

        if new_state is not None:

            if new_state not in visited:

                result = puzzle_dfs(
                    new_state,
                    goal,
                    visited,
                    path + [direction]
                )

                if result is not None:
                    return result

    return None


start = (0, 3, 2, 1)
goal = (1, 2, 3, 0)

visited = []

if solvable(start):

    solution = puzzle_dfs(start, goal, visited, [])

    print("DFS solution:", solution)

else:

    print("Not Solvable")
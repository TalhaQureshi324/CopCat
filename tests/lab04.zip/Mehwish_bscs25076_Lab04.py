# Task 1a - BFS

def bfs(edge, start):
    visited = []
    queue = []
    result = []

    queue.append(start)
    visited.append(start)

    while len(queue) > 0:
        current = queue.pop(0)
        result.append(current)

        index = ord(current) - ord('A')

        for i in range(len(edge[index])):
            neighbour = edge[index][i]

            if neighbour not in visited:
                visited.append(neighbour)
                queue.append(neighbour)

    return result


edge = [
    ["B", "C"],
    ["A", "D", "E"],
    ["A", "F"],
    ["B"],
    ["B"],
    ["C"]
]

start = "A"

print("BFS visit order:", bfs(edge, start))


# Task 1b - DFS

def dfs(edge, start):
    visited = []
    stack = []
    result = []

    stack.append(start)

    while len(stack) > 0:
        current = stack.pop()

        if current not in visited:
            visited.append(current)
            result.append(current)

            index = ord(current) - ord('A')

            for i in range(len(edge[index]) - 1, -1, -1):
                neighbour = edge[index][i]

                if neighbour not in visited:
                    stack.append(neighbour)

    return result


print("DFS visit order:", dfs(edge, start))


# Task 2 - 4 Puzzle

goal = (1, 2, 3, 0)


def solvable(state):
    numbers = []

    for x in state:
        if x != 0:
            numbers.append(x)

    inv = 0

    for i in range(len(numbers)):
        for j in range(i + 1, len(numbers)):
            if numbers[i] > numbers[j]:
                inv += 1

    blank = state.index(0)

    row_from_bottom = 2 - (blank // 2)

    return (inv + row_from_bottom) % 2 == 1


def get_neighbours(state):
    neighbours = []

    blank = state.index(0)

    row = blank // 2
    col = blank % 2

    moves = [
        (-1, 0, "Up"),
        (1, 0, "Down"),
        (0, -1, "Left"),
        (0, 1, "Right")
    ]

    for dr, dc, move in moves:

        new_row = row + dr
        new_col = col + dc

        if 0 <= new_row < 2 and 0 <= new_col < 2:

            new_blank = new_row * 2 + new_col

            new_state = list(state)

            new_state[blank], new_state[new_blank] = new_state[new_blank], new_state[blank]

            neighbours.append((tuple(new_state), move))

    return neighbours


def bfs_puzzle(start):
    queue = []

    queue.append((start, [], [start]))

    visited = set()
    visited.add(start)

    while len(queue) > 0:

        current, moves, path = queue.pop(0)

        if current == goal:
            return moves, path

        for neighbour, move in get_neighbours(current):

            if neighbour not in visited:

                visited.add(neighbour)

                queue.append(
                    (
                        neighbour,
                        moves + [move],
                        path + [neighbour]
                    )
                )

    return [], []


def dfs_puzzle(start):
    stack = []

    stack.append((start, [], [start]))

    visited = set()
    visited.add(start)

    while len(stack) > 0:

        current, moves, path = stack.pop()

        if current == goal:
            return moves, path

        neighbours = get_neighbours(current)

        for neighbour, move in reversed(neighbours):

            if neighbour not in visited:

                visited.add(neighbour)

                stack.append(
                    (
                        neighbour,
                        moves + [move],
                        path + [neighbour]
                    )
                )

    return [], []


def print_state(state):
    print(state[0], state[1])
    print(state[2], state[3])


start = (0, 3, 2, 1)


print()
print("Start:")
print_state(start)

print()
print("Goal:")
print_state(goal)

print()
print("Solvability test...")

if solvable(start):

    print("Solvable. Running BFS to find the shortest path...")

    moves, path = bfs_puzzle(start)

    print("Move count:", len(moves))

    print("Solution sequence:")

    for i in range(len(path)):

        print("Step", i, ":")

        print_state(path[i])

        if i < len(moves):
            print("Move:", moves[i])

        print()

    print("DFS solution:")

    dfs_moves, dfs_path = dfs_puzzle(start)

    print("Move count:", len(dfs_moves))

    for i in range(len(dfs_path)):

        print("Step", i, ":")

        print_state(dfs_path[i])

        if i < len(dfs_moves):
            print("Move:", dfs_moves[i])

        print()

else:

    print("Not solvable.")
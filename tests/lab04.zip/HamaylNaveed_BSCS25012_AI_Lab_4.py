#Task_1a
def bfs(graph, start_node):
    def get_index(node):
        return ord(node) - ord('A')
    
    def get_node(index):
        return chr(index + ord('A'))

    start_idx = get_index(start_node)
    visited = [False] * len(graph)
    
    queue = [start_idx]
    visited[start_idx] = True
    
    visit_order = []
    
    while len(queue) > 0:
        current_idx = queue.pop(0)
        visit_order.append(get_node(current_idx))
        
        for neighbor in graph[current_idx]:
            neighbor_idx = get_index(neighbor)
            if not visited[neighbor_idx]:
                visited[neighbor_idx] = True
                queue.append(neighbor_idx)
                
    return visit_order

#Task_1b
def dfs(graph, start_node):
    def get_index(node):
        return ord(node) - ord('A')
    
    def get_node(index):
        return chr(index + ord('A'))

    visited = [False] * len(graph)
    visit_order = []
    
    def dfs_recursive(current_idx):
        visited[current_idx] = True
        visit_order.append(get_node(current_idx))
        
        for neighbor in graph[current_idx]:
            neighbor_idx = get_index(neighbor)
            if not visited[neighbor_idx]:
                dfs_recursive(neighbor_idx)
                
    start_idx = get_index(start_node)
    dfs_recursive(start_idx)
    
    return visit_order

def is_solvable(state):
    tiles = [x for x in state if x != 0]
    inv = 0
    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            if tiles[i] > tiles[j]:
                inv += 1
                
    blank_idx = state.index(0)
    row_from_bottom = 1 if blank_idx >= 2 else 2
    
    return (inv + row_from_bottom) % 2 == 1

def print_state(state):
    print(f"{state[0]} {state[1]}")
    print(f"{state[2]} {state[3]}")

def get_neighbors(state):
    neighbors = []
    idx = state.index(0)
    
    if idx in (2, 3):
        new_idx = idx - 2
        new_state = list(state)
        new_state[idx], new_state[new_idx] = new_state[new_idx], new_state[idx]
        neighbors.append((tuple(new_state), 'Up'))
        
    if idx in (0, 1):
        new_idx = idx + 2
        new_state = list(state)
        new_state[idx], new_state[new_idx] = new_state[new_idx], new_state[idx]
        neighbors.append((tuple(new_state), 'Down'))
        
    if idx in (1, 3):
        new_idx = idx - 1
        new_state = list(state)
        new_state[idx], new_state[new_idx] = new_state[new_idx], new_state[idx]
        neighbors.append((tuple(new_state), 'Left'))
        
    if idx in (0, 2):
        new_idx = idx + 1
        new_state = list(state)
        new_state[idx], new_state[new_idx] = new_state[new_idx], new_state[idx]
        neighbors.append((tuple(new_state), 'Right'))
        
    return neighbors

def solve_bfs(initial_state):
    goal = (1, 2, 3, 0)
    if initial_state == goal:
        return []
        
    from collections import deque
    queue = deque([(initial_state, [])])
    visited = {initial_state}
    
    while queue:
        current, path = queue.popleft()
        
        for neighbor, move in get_neighbors(current):
            if neighbor == goal:
                return path + [(neighbor, move)]
                
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [(neighbor, move)]))
                
    return None

def solve_dfs(initial_state):
    goal = (1, 2, 3, 0)
    if initial_state == goal:
        return []
        
    stack = [(initial_state, [])]
    visited = {initial_state}
    
    while stack:
        current, path = stack.pop()
        
        if current == goal:
            return path
            
        for neighbor, move in get_neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                stack.append((neighbor, path + [(neighbor, move)]))
                
    return None

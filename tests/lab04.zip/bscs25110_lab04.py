nodes = ["A", "B", "C", "D", "E", "F"]

edge = [
    ["B", "C"],
    ["A", "D", "E"],
    ["A", "F"],
    ["B"],
    ["B"],
    ["C"]
]


def bfs(edge, start):
    visited = []
    queue = []
    visited.append(start)
    queue.append(start)
    while len(queue) > 0:
        node = queue.pop(0)
        i = nodes.index(node)
        for n in edge[i]:
            if n not in visited:
                visited.append(n)
                queue.append(n)
    return visited


def dfs(edge, start, visited):
    visited.append(start)
    i = nodes.index(start)
    for n in edge[i]:
        if n not in visited:
            dfs(edge, n, visited)
    return visited


print("BFS visit order:", bfs(edge, "A"))
print("DFS visit order:", dfs(edge, "A", []))
print()


goal = (1, 2, 3, 0)


def print_state(state):
    print(state[0], state[1])
    print(state[2], state[3])


def is_solvable(state):
    tiles = []
    for x in state:
        if x != 0:
            tiles.append(x)
    inv = 0
    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            if tiles[i] > tiles[j]:
                inv = inv + 1
    blank = state.index(0)
    if blank < 2:
        row_from_bottom = 2
    else:
        row_from_bottom = 1
    if (inv + row_from_bottom) % 2 == 1:
        return True
    else:
        return False


def swap(state, i, j):
    s = list(state)
    temp = s[i]
    s[i] = s[j]
    s[j] = temp
    return tuple(s)


def get_moves(state):
    moves = []
    b = state.index(0)
    if b >= 2:
        moves.append(["Up", swap(state, b, b - 2)])
    if b < 2:
        moves.append(["Down", swap(state, b, b + 2)])
    if b % 2 == 1:
        moves.append(["Left", swap(state, b, b - 1)])
    if b % 2 == 0:
        moves.append(["Right", swap(state, b, b + 1)])
    return moves


def bfs_puzzle(start):
    queue = []
    visited = []
    queue.append([start, []])
    visited.append(start)
    while len(queue) > 0:
        item = queue.pop(0)
        state = item[0]
        path = item[1]
        if state == goal:
            return path
        for m in get_moves(state):
            move_name = m[0]
            new_state = m[1]
            if new_state not in visited:
                visited.append(new_state)
                queue.append([new_state, path + [move_name]])
    return None


def dfs_puzzle(start):
    stack = []
    visited = []
    stack.append([start, []])
    while len(stack) > 0:
        item = stack.pop()
        state = item[0]
        path = item[1]
        if state in visited:
            continue
        visited.append(state)
        if state == goal:
            return path
        for m in get_moves(state):
            move_name = m[0]
            new_state = m[1]
            if new_state not in visited:
                stack.append([new_state, path + [move_name]])
    return None


def show_solution(start, path):
    print("Move count:", len(path))
    print("Solution sequence:")
    state = start
    print("Step 0:")
    print_state(state)
    step = 1
    for move in path:
        for m in get_moves(state):
            if m[0] == move:
                state = m[1]
        print("Step " + str(step) + ":")
        print_state(state)
        print("Move:", move)
        step = step + 1


start = (0, 3, 2, 1)

print("Start:")
print_state(start)
print("Goal:")
print_state(goal)
print("Solvability test...")

if is_solvable(start):
    print("Solvable. Running BFS to find the shortest path...")
    path = bfs_puzzle(start)
    show_solution(start, path)
    print()
    print("Running DFS...")
    path = dfs_puzzle(start)
    show_solution(start, path)
else:
    print("Not solvable.")

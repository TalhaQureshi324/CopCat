def bfs(graph, labels, start):
    visited = []
    queue = [start]          
    seen = {start}
    while queue:
        node = queue.pop(0) 
        visited.append(node)
        idx = labels.index(node)
        for neighbour in graph[idx]:
            if neighbour not in seen:
                seen.add(neighbour)
                queue.append(neighbour)
    return visited

def dfs(graph, labels, start):
    visited = []
    seen = {start}
    stack = [start]
    while stack:
        node = stack.pop()  
        visited.append(node)
        idx = labels.index(node)
        for neighbour in reversed(graph[idx]):
            if neighbour not in seen:
                seen.add(neighbour)
                stack.append(neighbour)
    return visited


GOAL = (1, 2, 3, 0)
MOVES = {
    "Up":    {2: 0, 3: 1},   
    "Down":  {0: 2, 1: 3},   
    "Left":  {1: 0, 3: 2},   
    "Right": {0: 1, 2: 3},   
}

def print_state(state):
    print(f"{state[0]} {state[1]}")
    print(f"{state[2]} {state[3]}")

def is_solvable(state):
    tiles = [t for t in state if t != 0]
    inv = 0
    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            if tiles[i] > tiles[j]:
                inv += 1
    blank_index = state.index(0)
    blank_row_from_top = blank_index // 2      
    row_from_bottom = 2 - blank_row_from_top    
    return (inv + row_from_bottom) % 2 == 1
 
def get_valid_moves(state):
    blank_index = state.index(0)
    valid = []
    for move_name, mapping in MOVES.items():
        if blank_index in mapping:
            swap_with = mapping[blank_index]
            new_state = list(state)
            new_state[blank_index], new_state[swap_with] = (
                new_state[swap_with],
                new_state[blank_index],
            )
            valid.append((move_name, tuple(new_state)))
    return valid

def solve_bfs(start_state):
    if start_state == GOAL:
        return [(start_state, None)]
    queue = [start_state]           
    visited = {start_state}
    parent = {start_state: (None, None)} 
    while queue:
        current = queue.pop(0)
        if current == GOAL:
            break
        for move_name, next_state in get_valid_moves(current):
            if next_state not in visited:
                visited.add(next_state)
                parent[next_state] = (current, move_name)
                queue.append(next_state)
    if GOAL not in parent:
        return None
    path = []
    node = GOAL
    while node is not None:
        prev_state, move = parent[node]
        path.append((node, move))
        node = prev_state
    path.reverse()
    return path
 
def solve_dfs(start_state, max_depth=50):
    stack = [(start_state, [(start_state, None)])]  # (state, path_so_far)
    visited = {start_state}
    while stack:
        current, path = stack.pop()
        if current == GOAL:
            return path
        if len(path) - 1 >= max_depth:
            continue
        for move_name, next_state in get_valid_moves(current):
            if next_state not in visited:
                visited.add(next_state)
                stack.append((next_state, path + [(next_state, move_name)]))
    return None
 
def print_solution(path, algorithm_name):
    print(f"\nMove count: {len(path) - 1}")
    print("Solution sequence:")
    for step, (state, move) in enumerate(path):
        print(f"Step {step}:")
        print_state(state)
        if move is not None:
            print(f"Move: {move}")
        print()
 
def run_puzzle_tasks():
    initial_state = (0, 3, 2, 1)
    print("=== Task 2: 4-Puzzle ===")
    print("Start:")
    print_state(initial_state)
    print("\nGoal:")
    print_state(GOAL)
    print("\nSolvability test...")
    if not is_solvable(initial_state):
        print("Not solvable.")
        return
    print("Solvable. Running BFS to find the shortest path...")
    bfs_path = solve_bfs(initial_state)
    print_solution(bfs_path, "BFS")
    print("=== Task 2b: DFS solution ===")
    dfs_path = solve_dfs(initial_state)
    if dfs_path is None:
        print("DFS could not find a solution within the depth limit.")
    else:
        print_solution(dfs_path, "DFS")

def run_graph_tasks():
    labels = ['A', 'B', 'C', 'D', 'E', 'F']
    edge = [
        ["B", "C"],       
        ["A", "D", "E"],  
        ["A", "F"],       
        ["B"],            
        ["B"],            
        ["C"]             
    ]
    start = "A"
 
    print("=== Task 1a: BFS ===")
    print("BFS visit order:", bfs(edge, labels, start))
 
    print("\n=== Task 1b: DFS ===")
    print("DFS visit order:", dfs(edge, labels, start))

run_graph_tasks()
print("\n" + "=" * 40 + "\n")
run_puzzle_tasks()
def index_of(lst, element):
    idx = 0
    for item in lst:
        if item == element:
            return idx
        idx += 1
    return -1

def task1a_bfs(edges, nodes, start):
    queue = [start]
    visited = [start]
    order = []
    
    while queue:
        current = queue[0]
        queue = queue[1:]
        order = order + [current]
        
        idx = index_of(nodes, current)
        for neighbor in edges[idx]:
            if index_of(visited, neighbor) == -1:
                visited = visited + [neighbor]
                queue = queue + [neighbor]
                
    return order

def task1b_dfs(edges, nodes, start):
    stack = [start]
    visited = []
    order = []
    
    while stack:
        current = stack[-1]
        stack = stack[:-1]
        
        if index_of(visited, current) == -1:
            visited = visited + [current]
            order = order + [current]
            idx = index_of(nodes, current)
            
            neighbors = edges[idx]
            rev_neighbors = []
            for n in neighbors:
                rev_neighbors = [n] + rev_neighbors
                
            for neighbor in rev_neighbors:
                if index_of(visited, neighbor) == -1:
                    stack = stack + [neighbor]
                    
    return order

def get_inversions(state):
    inv = 0
    flat = []
    for x in state:
        if x != 0:
            flat = flat + [x]
            
    flat_size = 0
    for _ in flat:
        flat_size += 1
        
    i = 0
    while i < flat_size:
        j = i + 1
        while j < flat_size:
            if flat[i] > flat[j]:
                inv += 1
            j += 1
        i += 1
    return inv

def get_row_from_bottom(state):
    if state[0] == 0 or state[1] == 0:
        return 2
    return 1

def is_solvable(state):
    inv = get_inversions(state)
    row = get_row_from_bottom(state)
    return (inv + row) % 2 == 1

def get_neighbors_puzzle(state):
    idx = 0
    for i in state:
        if i == 0:
            break
        idx += 1
        
    neighbors = []
    if idx == 0:
        s1 = (state[1], state[0], state[2], state[3])
        neighbors = neighbors + [(s1, "Right")]
        s2 = (state[2], state[1], state[0], state[3])
        neighbors = neighbors + [(s2, "Down")]
    elif idx == 1:
        s1 = (state[1], state[0], state[2], state[3])
        neighbors = neighbors + [(s1, "Left")]
        s2 = (state[0], state[3], state[2], state[1])
        neighbors = neighbors + [(s2, "Down")]
    elif idx == 2:
        s1 = (state[2], state[1], state[0], state[3])
        neighbors = neighbors + [(s1, "Up")]
        s2 = (state[0], state[1], state[3], state[2])
        neighbors = neighbors + [(s2, "Right")]
    elif idx == 3:
        s1 = (state[0], state[3], state[2], state[1])
        neighbors = neighbors + [(s1, "Up")]
        s2 = (state[0], state[1], state[3], state[2])
        neighbors = neighbors + [(s2, "Left")]
    return neighbors

def puzzle_bfs(start_state):
    goal = (1, 2, 3, 0)
    queue = [(start_state, [])]
    visited = [start_state]
    
    while queue:
        current, path = queue[0]
        queue = queue[1:]
        
        if current == goal:
            return path
            
        for neighbor, move in get_neighbors_puzzle(current):
            is_vis = False
            for v in visited:
                if v == neighbor:
                    is_vis = True
                    break
            if not is_vis:
                visited = visited + [neighbor]
                queue = queue + [(neighbor, path + [(neighbor, move)])]
    return []

def puzzle_dfs(start_state):
    goal = (1, 2, 3, 0)
    stack = [(start_state, [])]
    visited = [start_state]
    
    while stack:
        current, path = stack[-1]
        stack = stack[:-1]
        
        if current == goal:
            return path
            
        for neighbor, move in get_neighbors_puzzle(current):
            is_vis = False
            for v in visited:
                if v == neighbor:
                    is_vis = True
                    break
            if not is_vis:
                visited = visited + [neighbor]
                stack = stack + [(neighbor, path + [(neighbor, move)])]
    return []

def print_state(state):
    print(f"{state[0]} {state[1]}")
    print(f"{state[2]} {state[3]}")

nodes = ["A", "B", "C", "D", "E", "F"]
edges = [
    ["B", "C"],
    ["A", "D", "E"],
    ["A", "F"],
    ["B"],
    ["B"],
    ["C"]
]
start_node = "A"

print("Task 1a: BFS")
bfs_order = task1a_bfs(edges, nodes, start_node)
print(f"BFS visit order: {bfs_order}")

print("\nTask 1b: DFS")
dfs_order = task1b_dfs(edges, nodes, start_node)
print(f"DFS visit order: {dfs_order}")

print("\nTask 2: 4-Puzzle")
start_state = (0, 3, 2, 1)

print("Start:")
print_state(start_state)
print("Goal:")
print_state((1, 2, 3, 0))

print("Solvability test...")
if is_solvable(start_state):
    print("Solvable. Running BFS to find the shortest path...")
    solution_path = puzzle_bfs(start_state)
    
    step_count = 0
    for _ in solution_path:
        step_count += 1
        
    print(f"Move count: {step_count}")
    print("Solution sequence:")
    print("Step 0:")
    print_state(start_state)
    
    step_idx = 1
    for state, move in solution_path:
        print(f"Step {step_idx}:")
        print_state(state)
        print(f"Move: {move}")
        step_idx += 1
        
    print("\nRunning DFS...")
    dfs_solution_path = puzzle_dfs(start_state)
    dfs_step_count = 0
    for _ in dfs_solution_path:
        dfs_step_count += 1
    print(f"DFS found a solution with move count: {dfs_step_count}")
else:
    print("Not Solvable.")
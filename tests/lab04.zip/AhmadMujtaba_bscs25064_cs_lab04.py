


# Task 1a 
def bfs(edge, labels, start):
   
    visited_order = []
    visited_set = {start}
    queue = [start]                      

    while queue:
        node = queue.pop(0)  

        visited_order.append(node)

        idx = labels.index(node)

        for neighbour in edge[idx]:

            if neighbour not in visited_set:

                visited_set.add(neighbour)

                queue.append(neighbour)   

    return visited_order


# Task 1b 
def dfs(edge, labels, start):
   
    visited_order = []

    def _visit(node):
        visited_order.append(node)

        idx = labels.index(node)

        for neighbour in edge[idx]:

            if neighbour not in visited_order:

                _visit(neighbour)

    _visit(start)
    return visited_order


def dfs_iterative(edge, labels, start):
   
    visited_order = []

    visited_set = set()

    stack = [start]

    while stack:
        node = stack.pop()    

        if node in visited_set:
            continue
        visited_set.add(node)

        visited_order.append(node)

        idx = labels.index(node)
       
        for neighbour in reversed(edge[idx]):
            if neighbour not in visited_set:
                stack.append(neighbour)

    return visited_order


# Task 2 - 4-Puzzle


GOAL = (1, 2, 3, 0)


def print_state(state):
    print(f"{state[0]} {state[1]}")
    
    print(f"{state[2]} {state[3]}")


def is_solvable(state):
    tiles = [t for t in state if t != 0]
    inv = sum(
        1
        for i in range(len(tiles))

        for j in range(i + 1, len(tiles))

        if tiles[i] > tiles[j]
    )

    blank_idx = state.index(0)

    row_from_top = blank_idx // 2

    row_from_bottom = 2 - row_from_top     

    return (inv + row_from_bottom) % 2 == 1


def get_moves(state):
   
    idx = state.index(0)
    row, col = divmod(idx, 2)
    moves = []
    if row > 0:               
        moves.append(("Up", idx - 2))

    if row < 1:               
        moves.append(("Down", idx + 2))

    if col > 0:               
        moves.append(("Left", idx - 1))

    if col < 1:                
        moves.append(("Right", idx + 1))

    return moves


def apply_move(state, target_idx):
    state = list(state)

    blank_idx = state.index(0)

    state[blank_idx], state[target_idx] = state[target_idx], state[blank_idx]

    return tuple(state)


def bfs_solve(start, goal=GOAL):
    
    if start == goal:
        return [start], []

    visited = {start}
    queue = [(start, [start], [])]

    while queue:
        state, path_states, path_moves = queue.pop(0)

        for move_name, target_idx in get_moves(state):

            new_state = apply_move(state, target_idx)

            if new_state in visited:
                continue
            new_path_states = path_states + [new_state]

            new_path_moves = path_moves + [move_name]
            if new_state == goal:

                return new_path_states, new_path_moves
            visited.add(new_state)

            queue.append((new_state, new_path_states, new_path_moves))

    return None, None


def dfs_solve(start, goal=GOAL, max_depth=60):
    visited = set()

    path_states = [start]
    path_moves = []

    def _dfs(state, depth):

        if state == goal:
            return True
        
        if depth >= max_depth:
            return False
        
        visited.add(state)
        for move_name, target_idx in get_moves(state):

            new_state = apply_move(state, target_idx)

            if new_state not in visited:
                path_states.append(new_state)

                path_moves.append(move_name)
                if _dfs(new_state, depth + 1):
                    return True
                
                path_states.pop()

                path_moves.pop()
        return False

    found = _dfs(start, 0)
    return (path_states, path_moves) if found else (None, None)


def print_solution(states, moves, label):
    print(f"\n{label}")

    print(f"Move count: {len(moves)}")
    print("Solution sequence:")

    print("Step 0:")

    print_state(states[0])

    for i, (state, move) in enumerate(zip(states[1:], moves), start=1):
        print(f"Step {i}:")

        print_state(state)

        print(f"Move: {move}")



# main
if __name__ == "__main__":
    # Task 1a
    labels = ["A", "B", "C", "D", "E", "F"]
    edge = [
        ["B", "C"],        
        ["A", "D", "E"],   
        ["A", "F"],        
        ["B"],            
        ["B"],            
        ["C"],             
    ]
    start = "A"

    print("=" * 50)
    print("Task 1a - BFS")
    print("=" * 50)
    print("BFS visit order:", bfs(edge, labels, start))

    #  Task 1b: DFS 
    print("\n" + "=" * 50)
    print("Task 1b - DFS")
    print("=" * 50)
    print("DFS visit order (recursive):", dfs(edge, labels, start))
    print("DFS visit order (iterative):", dfs_iterative(edge, labels, start))

    #  Task 2: 4-Puzzle
    print("\n" + "=" * 50)
    print("Task 2 - 4-Puzzle")
    print("=" * 50)

    initial_state = (0, 3, 2, 1)

    print("Start:")
    print_state(initial_state)
    print("Goal:")
    print_state(GOAL)

   
    if is_solvable(initial_state):
        print("Solvable. Running BFS to find the shortest path...")
        states, moves = bfs_solve(initial_state)
        print_solution(states, moves, "1) BFS solution")

        print()
        d_states, d_moves = dfs_solve(initial_state)
        print_solution(d_states, d_moves, "2) DFS solution")
    else:
        print("Not solvable.")
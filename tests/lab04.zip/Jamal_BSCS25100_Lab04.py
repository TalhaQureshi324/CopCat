edge = [
    ["B", "C"],["A", "D", "E"],["A", "F"],["B"],["B"],["C"]
]
nodes = ["A", "B", "C", "D", "E", "F"]
# Task 1a
def bfs_mtrx(edge, s):
    vs = []
    q = [s]
    while q:
        nd = q.pop(0)
        if nd not in vs:
            vs.append(nd)
            i = nodes.index(nd)
            for nbr in edge[i]:
                if nbr not in vs and nbr not in q:
                    q.append(nbr)
    return vs
# Task 1b
def dfs_mtrx(edge, s):
    vs = []
    st = [s]
    while st:
        nd = st.pop()
        if nd not in vs:
            vs.append(nd)
            i = nodes.index(nd)
            for nbr in reversed(edge[i]):
                if nbr not in vs:
                    st.append(nbr)
    return vs
# Task 2a
def chk_sol(s):
    arr = [x for x in s if x != 0]
    inv = 0
    if arr[0] > arr[1]: inv += 1
    if arr[0] > arr[2]: inv += 1
    if arr[1] > arr[2]: inv += 1  
    z = s.index(0)
    rfb = 2 if z < 2 else 1
    return (inv + rfb) % 2 == 1
def get_nbrs(st):
    nbrs = []
    z = st.index(0)
    r = z // 2
    c = z % 2  
    if r < 1:
        s = list(st)
        s[z], s[z + 2] = s[z + 2], s[z]
        nbrs.append((tuple(s), "Down"))
    if c < 1:
        s = list(st)
        s[z], s[z + 1] = s[z + 1], s[z]
        nbrs.append((tuple(s), "Right"))
    if r > 0:
        s = list(st)
        s[z], s[z - 2] = s[z - 2], s[z]
        nbrs.append((tuple(s), "Up"))
    if c > 0:
        s = list(st)
        s[z], s[z - 1] = s[z - 1], s[z]
        nbrs.append((tuple(s), "Left"))
    return nbrs
def print_b(st):
    print(f"{st[0]} {st[1]}")
    print(f"{st[2]} {st[3]}")
def bfs_puzzle(s_st, g_st=(1, 2, 3, 0)):
    print("Start:")
    print_b(s_st)
    print("Goal:")
    print_b(g_st)
    print("solvability test")
    if not chk_sol(s_st):
        print("not solvable")
        return
    print("it is solvable") 
    q = [(s_st, [])]
    vs = [s_st] 
    while q:
        curr, pth = q.pop(0)
        if curr == g_st:
            print(f"Move count: {len(pth)}")
            print("Solution sequence:")
            print("Step 0:")
            print_b(s_st)
            for i, (m, st_nxt) in enumerate(pth, 1):
                print(f"Step {i}:")
                print_b(st_nxt)
                print(f"Move: {m}")
            return pth
        for nxt, m in get_nbrs(curr):
            if nxt not in vs:
                vs.append(nxt)
                q.append((nxt, pth + [(m, nxt)]))

# Task 2b Algorithm:
# 1. Check solvability using formula (inv + rfb) % 2 == 1.
# 2. Push start state and empty path to stack; mark start as visited.
# 3. Pop top state from stack. If it equals goal state, return path.
# 4. Generate valid moves (Up, Down, Left, Right) for blank tile (0).
# 5. Push unvisited neighbors and updated paths to stack until solution is found.
def dfs_puzzle(s_st, g_st=(1, 2, 3, 0)):
    if not chk_sol(s_st):
        return None
    stk = [(s_st, [])]
    vs = [s_st]
    while stk:
        curr, pth = stk.pop()
        if curr == g_st:
            return pth
        for nxt, m in reversed(get_nbrs(curr)):
            if nxt not in vs:
                vs.append(nxt)
                stk.append((nxt, pth + [(m, nxt)]))
    return None
if __name__ == "__main__":
    start = "A"
    print("BFS visit order:", bfs_mtrx(edge, start))
    print("DFS visit order:", dfs_mtrx(edge, start))
    print("\n 4 puzzle bfs")
    init_st = (0, 3, 2, 1)
    bfs_puzzle(init_st)
    print("\n4 puzzle dfs")
    dfs_res = dfs_puzzle(init_st)
    print("dFS Path Steps:", len(dfs_res) if dfs_res else "No path")
class GraphBFS:
    def __init__(self, edges: list):
        self.edges = edges

    def _get_node_index(self, node: str) -> int:
        """Converts character nodes to integer indices (e.g., 'A' -> 0)."""
        return ord(node) - ord('A')

    def traverse(self, start_node: str) -> list:
        queue = [start_node]
        vis = [start_node]
        vis_ord = []

        while queue:
            # Using pop(0) on a standard list to enforce FIFO without a deque
            cur = queue.pop(0)
            vis_ord.append(cur)
            
            n_idx = self._get_node_index(cur)
            ngh = self.edges[n_idx]
            
            for neighbor in ngh:
                if neighbor not in vis:
                    vis.append(neighbor)
                    queue.append(neighbor)
                    
        return vis_ord

# The list representation of the graph
edge = [
    ["B", "C"],       # neighbours of A[cite: 1]
    ["A", "D", "E"],  # neighbours of B[cite: 1]
    ["A", "F"],       # neighbours of C[cite: 1]
    ["B"],            # neighbours of D[cite: 1]
    ["B"],            # neighbours of E[cite: 1]
    ["C"]             # neighbours of F[cite: 1]
]

bfs_graph = GraphBFS(edge)
print("BFS visit order:", bfs_graph.traverse("A"))
















# Task 1b

class GraphDFS:
    def __init__(self, edges: list):
        self.edges = edges

    def _get_node_index(self, node: str) -> int:

        """Converts character nodes to integer indices (e.g., 'A' -> 0)."""
        return ord(node) - ord('A')

    def traverse(self, start_node: str) -> list:

        stack = [start_node]
        vis = []
        vis_ord = []

        while stack:
            # Using pop() on a standard list to enforce LIFO stack behavior
            cur = stack.pop()
            
            if cur not in vis:
                vis.append(cur)
                vis_ord.append(cur)
                
                n_idx = self._get_node_index(cur)
                ngh = self.edges[n_idx]
                
                # Push neighbors in reverse order to explore 'B' before 'C'
                for i in range(len(ngh) - 1, -1, -1):
                    neighbor = ngh[i]


                    if neighbor not in vis:
                        stack.append(neighbor)
                        
        return vis_ord

# The list representation of the graph[cite: 1]
edge = [
    ["B", "C"],       # neighbours of A[cite: 1]
    ["A", "D", "E"],  # neighbours of B[cite: 1]
    ["A", "F"],       # neighbours of C[cite: 1]
    ["B"],            # neighbours of D[cite: 1]
    ["B"],            # neighbours of E[cite: 1]
    ["C"]             # neighbours of F[cite: 1]
]

dfs_graph = GraphDFS(edge)
print("DFS visit order:", dfs_graph.traverse("A"))

















#Task 2
def check_solvability(state):
   
    f_list = []
    for i in range(4):
        if state[i] != 0:
            f_list.append(state[i])
            
    inv = 0
    for i in range(len(f_list)):
        for j in range(i + 1, len(f_list)):
            if f_list[i] > f_list[j]:
                inv += 1
                
    b_idx = 0
    for i in range(4):
        if state[i] == 0:
            b_idx = i
            break
            
  
    row_from_bottom = 1 if b_idx >= 2 else 2
    

   
    return (inv + row_from_bottom) % 2 == 1

def get_neighbors(state):
   
    ngh = []
    b_idx = 0
    for i in range(4):
        if state[i] == 0:
            b_idx = i
            break
            
   
    m = [(-2, "Up"), (2, "Down"), (-1, "Left"), (1, "Right")]
    
    for i in range(4):

        d = m[i][0]
        mn = m[i][1]
        nb_idx = b_idx + d


        
        if 0 <= nb_idx < 4:

           
            if mn == "Left" and b_idx % 2 == 0:
                continue
            if mn == "Right" and b_idx % 2 == 1:
                continue
                
            new_state = list(state)
            new_state[b_idx], new_state[nb_idx] = new_state[nb_idx], new_state[b_idx]
            ngh.append((tuple(new_state), mn))
            
    return ngh

def print_board(state):

    print(str(state[0]) + " " + str(state[1]))
    print(str(state[2]) + " " + str(state[3]))


def solve_bfs(start_state):
   
    if not check_solvability(start_state):
        return None
        
    goal_state = (1, 2, 3, 0)
    queue = [(start_state, [])]
    vis = [start_state]
    
    while len(queue) > 0:

        current_state, path = queue.pop(0)
        
        if current_state == goal_state:
            return path
            
        ngh = get_neighbors(current_state)

        for i in range(len(ngh)):

            next_state, mn = ngh[i]
            if next_state not in vis:
                vis.append(next_state)
                new_path = list(path)
                new_path.append((next_state, mn))
                queue.append((next_state, new_path))
                
    return None

def solve_dfs(start_state):

    if not check_solvability(start_state):
        return None
        
    goal_state = (1, 2, 3, 0)
    stack = [(start_state, [])]
    vis = []
    
    while len(stack) > 0:

        current_state, path = stack.pop()
        
        if current_state == goal_state:
            return path
            
        if current_state not in vis:
            vis.append(current_state)
            
            neighbors = get_neighbors(current_state)
            for i in range(len(neighbors) - 1, -1, -1):
                next_state, move_name = neighbors[i]
                if next_state not in vis:
                    new_path = list(path)
                    new_path.append((next_state, move_name))
                    stack.append((next_state, new_path))
                    
    return None


# --- Execution ---

initial_state = (0, 3, 2, 1)

print("Start:")
print_board(initial_state)
print("\nGoal:")
print_board((1, 2, 3, 0))

print("\nSolvability test...")

if check_solvability(initial_state):
    print("Solvable. Running BFS to find the shortest path...\n")
    shortest_path = solve_bfs(initial_state)
    
    print("Move count:", len(shortest_path))
    print("Solution sequence:")
    
    print("Step 0:")
    print_board(initial_state)
    
    for i in range(len(shortest_path)):
        next_state, move_name = shortest_path[i]
        print("\nStep " + str(i + 1) + ":")
        print_board(next_state)
        print("Move: " + move_name)

        
    print("\n--- Running DFS ---")
    dfs_path = solve_dfs(initial_state)
    print("DFS found a path with Move count:", len(dfs_path))
else:
    print("Not solvable.")




nodes = ["A", "B", "C", "D", "E", "F"]

edges = [
    ["B", "C"],
    ["A", "D", "E"],
    ["A", "F"],
    ["B"],
    ["B"],
    ["C"]
]


def bfs(edge, start):

    queue = [start]
    visited = [start]
    order = []

    front = 0

    while front < len(queue):

        current = queue[front]
        front = front + 1

        order.append(current)

        index = nodes.index(current)

        for neighbor in edge[index]:

            if neighbor not in visited:

                visited.append(neighbor)
                queue.append(neighbor)

    return order


start = "A"

result = bfs(edges, start)

print("BFS Traversal Order:", result)


nodes = ["A", "B", "C", "D", "E", "F"]

edges = [
    ["B", "C"],
    ["A", "D", "E"],
    ["A", "F"],
    ["B"],
    ["B"],
    ["C"]
]


def dfs(edge, current, visited, order):

    visited.append(current)
    order.append(current)

    index = nodes.index(current)

    for neighbor in edge[index]:

        if neighbor not in visited:

            dfs(edge, neighbor, visited, order)


visited = []
order = []

start = "A"

dfs(edges, start, visited, order)

print("DFS Traversal Order:", order)


goal = (1, 2, 3, 0)

initial = (0, 3, 2, 1)


def is_solvable(state):

    numbers = []

    for value in state:

        if value != 0:

            numbers.append(value)

    inversions = 0

    for i in range(len(numbers)):

        for j in range(i + 1, len(numbers)):

            if numbers[i] > numbers[j]:

                inversions = inversions + 1

    blank_index = state.index(0)

    if blank_index == 0 or blank_index == 1:

        row_from_bottom = 2

    else:

        row_from_bottom = 1

    if (inversions + row_from_bottom) % 2 == 1:

        return True

    else:

        return False


def swap(state, first, second):

    new_state = list(state)

    temp = new_state[first]

    new_state[first] = new_state[second]

    new_state[second] = temp

    return tuple(new_state)


def get_moves(state):

    moves = []

    blank = state.index(0)

    row = blank // 2

    column = blank % 2

    if row > 0:

        new_state = swap(state, blank, blank - 2)

        moves.append((new_state, "Up"))

    if row < 1:

        new_state = swap(state, blank, blank + 2)

        moves.append((new_state, "Down"))

    if column > 0:

        new_state = swap(state, blank, blank - 1)

        moves.append((new_state, "Left"))

    if column < 1:

        new_state = swap(state, blank, blank + 1)

        moves.append((new_state, "Right"))

    return moves


def puzzle_bfs(start):

    queue = [(start, [start], [])]

    visited = [start]

    front = 0

    while front < len(queue):

        current, path, moves = queue[front]

        front = front + 1

        if current == goal:

            return path, moves

        next_states = get_moves(current)

        for next_state, move in next_states:

            if next_state not in visited:

                visited.append(next_state)

                new_path = path + [next_state]

                new_moves = moves + [move]

                queue.append((next_state, new_path, new_moves))

    return None, None


def puzzle_dfs(current, visited, path, moves):

    if current == goal:

        return True

    next_states = get_moves(current)

    for next_state, move in next_states:

        if next_state not in visited:

            visited.append(next_state)

            path.append(next_state)

            moves.append(move)

            found = puzzle_dfs(
                next_state,
                visited,
                path,
                moves
            )

            if found == True:

                return True

            path.pop()

            moves.pop()

    return False


def print_board(state):

    print(state[0], state[1])

    print(state[2], state[3])


print()

print("Start:")

print_board(initial)

print()

print("Goal:")

print_board(goal)

print()

print("Solvability test...")


if is_solvable(initial) == False:

    print("Puzzle is not solvable.")

else:

    print("Solvable. Running BFS to find the shortest path...")

    path, moves = puzzle_bfs(initial)

    print()

    print("BFS Solution:")

    print("Move count:", len(moves))

    print("Solution sequence:")

    for i in range(len(path)):

        print()

        print("Step", i, ":")

        print_board(path[i])

        if i > 0:

            print("Move:", moves[i - 1])

    print()

    print("DFS Solution:")

    visited = [initial]

    dfs_path = [initial]

    dfs_moves = []

    found = puzzle_dfs(
        initial,
        visited,
        dfs_path,
        dfs_moves
    )

    if found == True:

        print("Move count:", len(dfs_moves))

        for i in range(len(dfs_path)):

            print()

            print("Step", i, ":")

            print_board(dfs_path[i])

            if i > 0:

                print("Move:", dfs_moves[i - 1])

    else:

        print("No solution found.")
print("Task 1a")
edge = [
    ["B", "C"],          
    ["A", "D", "E"],    
    ["A", "F"],          
    ["B"],              
    ["B"],               
    ["C"]                ]


nodes = ["A", "B", "C", "D", "E", "F"]


def bfs(edge, nodes, start):
    done = []
    list = []

    list.append(start)
    done.append(start)

    while list:
        current = list.pop(0)

        for neighbour in edge[nodes.index(current)]:
            if (neighbour not in done):
                done.append(neighbour)
                list.append(neighbour)

    return done

print("BFS visit order:", bfs(edge, nodes, "A"))
print("Task 1b")

def dfs(edge, nodes, start):
    done = []
    list = []
    list.append(start)
    while list:
        current = list.pop()
        if (current not in done):
            done.append(current)
            neighbours = edge[nodes.index(current)]
            for neighbour in reversed(neighbours):
                if (neighbour not in done):
                    list.append(neighbour)

    return done

print("DFS visit order:", dfs(edge, nodes, "A"))
print("Task 2")
Target = (1, 2, 3, 0)
def is_solvable(state):
    values = []
    for x in state:
        if (x != 0):
            values.append(x)

    a = 0

    for i in range(len(values)):
        for j in range(i + 1, len(values)):
            if (values[i] > values[j]):
                a += 1
    b_index = state.index(0)
    row_bottom = 2 - (b_index // 2)
    return (a + row_bottom) % 2 == 1
def get_moves(state):
    moves = []
    empty = state.index(0)
    row = empty // 2
    col = empty % 2
    if (row > 0):
        n = list(state)
        n[empty], n[empty - 2] = \
            n[empty - 2], n[empty]
        moves.append((tuple(n), "Up"))

    if (row < 1):
        n = list(state)
        n[empty], n[empty + 2] = \
            n[empty + 2], n[empty]
        moves.append((tuple(n), "Down"))

    if (col > 0):
        n = list(state)
        n[empty], n[empty - 1] = \
            n[empty - 1], n[empty]
        moves.append((tuple(n), "Left"))

    if (col < 1):
        n = list(state)
        n[empty], n[empty + 1] = \
            n[empty + 1], n[empty]
        moves.append((tuple(n), "Right"))

    return moves
def print_state(state):
    print(state[0], state[1])
    print(state[2], state[3])
print("Task 2a")
def puzzle_bfs(start):

    list = []
    done = []

    list.append((start, [], []))
    done.append(start)

    while list:

        current, way, moves = list.pop(0)

        if (current == Target):
            return way, moves

        for next_state, move in get_moves(current):

            if (next_state not in done):

                done.append(next_state)

                new_way = way + [next_state]
                new_moves = moves + [move]

                list.append(
                    (next_state, new_way, new_moves)
                )

    return None, None
print("Task 2b")
def puzzle_dfs(start):

    list = []
    done = []

    list.append((start, [], []))

    while list:

        current, way, moves = list.pop()

        if (current in done):
            continue

        done.append(current)

        if (current == Target):
            return way, moves

        possible_moves = get_moves(current)
        for next_state, move in reversed(possible_moves):
            if (next_state not in done):
                new_way = way + [next_state]
                new_moves = moves + [move]
                list.append(
                    (next_state, new_way, new_moves)
                )

    return None, None

#main
start = (0, 3, 2, 1)
print("Start:")
print_state(start)

print("Goal:")
print_state(Target)
print("Solvability test")

if (is_solvable(start)):

    print("Solvable.")

    path, moves = puzzle_bfs(start)

    print("Move count:", len(moves))
    print("Solution sequence:")

    print("Step 0:")
    print_state(start)

    for i in range(len(moves)):

        print("Move:", moves[i])

        print("Step", i + 1, ":")
        print_state(path[i])

else:

    print("Not solvable.")
print("DFS Solution")
if (is_solvable(start)):
    path, moves = puzzle_dfs(start)
    print("DFS move count:", len(moves))
    print("Step 0:")
    print_state(start)
    for i in range(len(moves)):
        print("Move:", moves[i])

        print("Step", i + 1, ":")
        print_state(path[i])

else:

    print("Puzzle is not solvable.")
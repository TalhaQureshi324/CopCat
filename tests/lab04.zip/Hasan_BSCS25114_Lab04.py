# TASK 01 A

edge = [
    ["B", "C"], # neighbours of A
    ["A", "D", "E"], # neighbours of B
    ["A", "F"], # neighbours of C
    ["B"], # neighbours of D
    ["B"], # neighbours of E
    ["C"] # neighbours of F
]

start = "A"

def bfs(neighbours:list, start_pos:str):
    path = []
    path.append(start_pos)
    size = len(neighbours)
    
    for i in range(size):
        for n in neighbours[i]:
            if n not in path:
                path.append(n)
    return path

x = bfs(edge, start)
print("BSF visit order: ", x)

# TASK 01 B

def dfs(neighbours:list, start_pos:str):
    path = []
    trv = [start_pos]
    
    while trv:
        ce = trv.pop()

        if ce not in path:
            path.append(ce)
        
        i = ord(ce) - 65

        for j in range(len(neighbours[i]) - 1, -1, -1):
            n = neighbours[i][j]
            if n not in path:
                trv.append(n)

    return path

x = dfs(edge, start)
print("BSF visit order: ", x)

# TASK 02 A

start = [0, 3, 2, 1]
goal = [1, 2, 3, 0]

def solvable(board):
    inv = 0
    tiles = []
    for x in board:
        if x != 0:
            tiles.append(x)
            
    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            if tiles[i] > tiles[j]:
                inv += 1
                
    zero_pos = board.index(0)
    if zero_pos < 2:
        row = 2
    else:
        row = 1
        
    return ((inv + row) % 2 == 1)


def bsf_puzzle(start_board):
    if not solvable(start_board):
        return "Not Solbable"
    
    queue = [start_board]
    moves = [[]]
    visited = [start_board]
    
    while queue:
        curr = queue.pop(0)
        path = moves.pop(0)
        
        if curr == goal:
            return path
        
        zero_pos = curr.index(0)
        
        pos_swaps = []
        if zero_pos == 0:
            pos_swaps = [("Down", 2), ("Right", 1)]
        elif zero_pos == 1:
            pos_swaps = [("Down", 3), ("Left", 0)]
        elif zero_pos == 2:
            pos_swaps = [("Up", 0), ("Right", 3)]
        elif zero_pos == 3:
            pos_swaps = [("Up", 1), ("Left", 2)]
            
        for move_name, swap_pos in pos_swaps:
            new_board = list(curr)
            temp = new_board[zero_pos]
            new_board[zero_pos] = new_board[swap_pos]
            new_board[swap_pos] = temp
            
            if new_board not in visited:
                visited.append(new_board)
                queue.append(new_board)
                moves.append(path + [move_name])

    return "No solution"

ans = bsf_puzzle(start)
print("Path:", ans)

# TSAK 02 B

def dsf_puzzle(start_board):
    if not solvable(start_board):
        return "Not solvable"
    
    stack = [start_board]
    moves = [[]]
    visited = [start_board]
    
    while stack:
        curr = stack.pop()
        path = moves.pop()
        
        if curr == goal:
            return path
        
        zero_pos = curr.index(0)
        pos_swaps = []
        if zero_pos == 0:
            pos_swaps = [("Right", 1), ("Dowm", 2)]
        elif zero_pos == 1:
            pos_swaps = [("Left", 0), ("Down", 3)]
        elif zero_pos == 2:
            pos_swaps = [("Right", 3), ("Up", 0)]
        elif zero_pos == 3:
            pos_swaps = [("Left", 2), ("Up", 1)]
            
        for move_name, swap_pos in pos_swaps:
            new_board = list(curr)
            temp = new_board[zero_pos]
            new_board[zero_pos] = new_board[swap_pos]
            new_board[swap_pos] = temp
            
            if new_board not in visited:
                visited.append(new_board)
                stack.append(new_board)
                moves.append(path + [move_name])

    return "No solution"

ans = dsf_puzzle(start)
print("DFS Path:", ans)
print("Total Moves:", len(ans))
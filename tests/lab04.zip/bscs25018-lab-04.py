def bfs_traversal(edge, start_node):
    # Map nodes to their corresponding index for easy lookup
    # Nodes are assumed to be 'A', 'B', 'C', 'D', 'E', 'F' based on index order
    nodes = ['A', 'B', 'C', 'D', 'E', 'F']
    start_index = nodes.index(start_node)
    
    visited = []
    queue = [start_index]  # Using a standard Python list as a queue
    
    # Keep track of visited nodes using a boolean list
    is_visited = [False] * len(nodes)
    is_visited[start_index] = True
    
    while len(queue) > 0:
        # Dequeue the front node
        current_index = queue.pop(0)
        current_node = nodes[current_index]
        visited.append(current_node)
        
        # Get neighbors of the current node from the edge list
        neighbors = edge[current_index]
        
        # Explore neighbors
        for neighbor in neighbors:
            neighbor_index = nodes.index(neighbor)
            if not is_visited[neighbor_index]:
                is_visited[neighbor_index] = True
                queue.append(neighbor_index)
                
    return visited

# --- Sample Input Test ---
edge = [
    ["B", "C"],       # neighbours of A[cite: 1]
    ["A", "D", "E"],  # neighbours of B[cite: 1]
    ["A", "F"],       # neighbours of C[cite: 1]
    ["B"],            # neighbours of D[cite: 1]
    ["B"],            # neighbours of E[cite: 1]
    ["C"]             # neighbours of F[cite: 1]
]
start = "A"

# Run BFS
output = bfs_traversal(edge, start)
print("BFS visit order:", output)

def dfs_traversal(edge, start_node):
    # Map nodes to their corresponding index for easy lookup
    nodes = ['A', 'B', 'C', 'D', 'E', 'F']
    start_index = nodes.index(start_node)
    
    visited = []
    stack = [start_index]  # Using a standard Python list as a stack
    
    # Keep track of visited nodes using a boolean list
    is_visited = [False] * len(nodes)
    
    while len(stack) > 0:
        # Pop the top node from the stack
        current_index = stack.pop()
        
        if not is_visited[current_index]:
            is_visited[current_index] = True
            current_node = nodes[current_index]
            visited.append(current_node)
            
            # Get neighbors of the current node from the edge list
            neighbors = edge[current_index]
            
            # To match typical DFS traversal order (visiting left-to-right),
            # we iterate through neighbors in reverse order before pushing to the stack.
            for neighbor in reversed(neighbors):
                neighbor_index = nodes.index(neighbor)
                if not is_visited[neighbor_index]:
                    stack.append(neighbor_index)
                
    return visited

# --- Sample Input Test ---
edge = [
    ["B", "C"],       # neighbours of A[cite: 1]
    ["A", "D", "E"],  # neighbours of B[cite: 1]
    ["A", "F"],       # neighbours of C[cite: 1]
    ["B"],            # neighbours of D[cite: 1]
    ["B"],            # neighbours of E[cite: 1]
    ["C"]             # neighbours of F[cite: 1]
]
start = "A"

# Run DFS
output = dfs_traversal(edge, start)
print("DFS visit order:", output)







def count_inversions(state):
    # Flatten the state and ignore the blank (0)
    flat = [tile for tile in state if tile != 0]
    inv = 0
    for i in range(len(flat)):
        for j in range(i + 1, len(flat)):
            if flat[i] > flat[j]:
                inv += 1
    return inv

def get_row_from_bottom(state):
    # Find index of the blank (0)
    blank_index = state.index(0)
    # Indices 0, 1 are top row (row 2 from bottom)
    # Indices 2, 3 are bottom row (row 1 from bottom)
    if blank_index < 2:
        return 2  # top row
    else:
        return 1  # bottom row

def is_solvable(state):
    inv = count_inversions(state)
    row_from_bottom = get_row_from_bottom(state)
    # Solvable condition for 2x2 grid: (inv + row_from_bottom) % 2 == 1
    return (inv + row_from_bottom) % 2 == 1

def get_neighbors(state):
    neighbors = []
    blank_idx = state.index(0)
    
    # Map index to (row, col)
    row, col = divmod(blank_idx, 2)
    
    # Possible moves for the blank: Up, Down, Left, Right
    moves = {
        'Up': (-1, 0),
        'Down': (1, 0),
        'Left': (0, -1),
        'Right': (0, 1)
    }
    
    for move_name, (dr, dc) in moves.items():
        new_row, new_col = row + dr, col + dc
        if 0 <= new_row < 2 and 0 <= new_col < 2:
            new_blank_idx = new_row * 2 + new_col
            # Swap blank with the adjacent tile
            state_list = list(state)
            state_list[blank_idx], state_list[new_blank_idx] = state_list[new_blank_idx], state_list[blank_idx]
            neighbors.append((tuple(state_list), move_name))
            
    return neighbors

def solve_puzzle_bfs(initial_state):
    goal_state = (1, 2, 3, 0)
    
    print("Solvability test...")
    if not is_solvable(initial_state):
        return "Not solvable."
    print("Solvable. Running BFS to find the shortest path...\n")
    
    queue = [(initial_state, [])]
    visited = {initial_state}
    
    while queue:
        current_state, path = queue.pop(0)
        
        if current_state == goal_state:
            return path
            
        for neighbor, move in get_neighbors(current_state):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [(move, neighbor)]))
                
    return None

def solve_puzzle_dfs(initial_state):
    goal_state = (1, 2, 3, 0)
    
    if not is_solvable(initial_state):
        return "Not solvable."
        
    stack = [(initial_state, [])]
    visited = set()
    
    while stack:
        current_state, path = stack.pop()
        
        if current_state == goal_state:
            return path
            
        if current_state not in visited:
            visited.add(current_state)
            # Push neighbors to stack (reversed to maintain left-to-right processing order if needed)
            for neighbor, move in reversed(get_neighbors(current_state)):
                if neighbor not in visited:
                    stack.append((neighbor, path + [(move, neighbor)]))
                    
    return None

# --- Sample Input Test ---
initial_state = (0, 3, 2, 1) # Corresponds to: 0 3 / 2 1[cite: 1]

print("Initial State:", initial_state)
solution_path = solve_puzzle_bfs(initial_state)

if isinstance(solution_path, list):
    print(f"Move count: {len(solution_path)}")
    print("Solution sequence:")
    print(f"Step 0:\n{initial_state[0]} {initial_state[1]}\n{initial_state[2]} {initial_state[3]}")
    for step_num, (move, state) in enumerate(solution_path, 1):
        print(f"\nStep {step_num}:")
        print(f"{state[0]} {state[1]}\n{state[2]} {state[3]}")
        print(f"Move: {move}")
else:
    print(solution_path)




def count_inversions(state):
    # Flatten the state and ignore the blank (0)
    flat = [tile for tile in state if tile != 0]
    inv = 0
    for i in range(len(flat)):
        for j in range(i + 1, len(flat)):
            if flat[i] > flat[j]:
                inv += 1
    return inv

def get_row_from_bottom(state):
    # Find index of the blank (0)
    blank_index = state.index(0)
    # Indices 0, 1 are top row (row 2 from bottom)
    # Indices 2, 3 are bottom row (row 1 from bottom)
    if blank_index < 2:
        return 2  # top row
    else:
        return 1  # bottom row

def is_solvable(state):
    inv = count_inversions(state)
    row_from_bottom = get_row_from_bottom(state)
    # Solvable condition for 2x2 grid: (inv + row_from_bottom) % 2 == 1[cite: 1]
    return (inv + row_from_bottom) % 2 == 1

def get_neighbors(state):
    neighbors = []
    blank_idx = state.index(0)
    row, col = divmod(blank_idx, 2)
    
    moves = {
        'Up': (-1, 0),
        'Down': (1, 0),
        'Left': (0, -1),
        'Right': (0, 1)
    }
    
    for move_name, (dr, dc) in moves.items():
        new_row, new_col = row + dr, col + dc
        if 0 <= new_row < 2 and 0 <= new_col < 2:
            new_blank_idx = new_row * 2 + new_col
            state_list = list(state)
            state_list[blank_idx], state_list[new_blank_idx] = state_list[new_blank_idx], state_list[blank_idx]
            neighbors.append((tuple(state_list), move_name))
            
    return neighbors

# --- Task 2a: BFS Solution (Shortest Path) ---
def solve_puzzle_bfs(initial_state):
    goal_state = (1, 2, 3, 0) #[cite: 1]
    
    if not is_solvable(initial_state):
        return "Not solvable."
    
    queue = [(initial_state, [])]
    visited = {initial_state}
    
    while queue:
        current_state, path = queue.pop(0)
        
        if current_state == goal_state:
            return path
            
        for neighbor, move in get_neighbors(current_state):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [(move, neighbor)]))
                
    return None

# --- Task 2b: DFS Solution ---
def solve_puzzle_dfs(initial_state):
    goal_state = (1, 2, 3, 0) #[cite: 1]
    
    if not is_solvable(initial_state):
        return "Not solvable."
        
    stack = [(initial_state, [])]
    visited = set()
    
    while stack:
        current_state, path = stack.pop()
        
        if current_state == goal_state:
            return path
            
        if current_state not in visited:
            visited.add(current_state)
            for neighbor, move in reversed(get_neighbors(current_state)):
                if neighbor not in visited:
                    stack.append((neighbor, path + [(move, neighbor)]))
                    
    return None

# --- Sample Input Test ---
initial_state = (0, 3, 2, 1) # Corresponds to input A = (0, 3, 2, 1)[cite: 1]
print(f"Initial State:\n{initial_state[0]} {initial_state[1]}\n{initial_state[2]} {initial_state[3]}\n")

# Run BFS
print("--- Running BFS (Shortest Path) ---")
bfs_path = solve_puzzle_bfs(initial_state)
if isinstance(bfs_path, list):
    print(f"BFS Move count: {len(bfs_path)}")
    for step_num, (move, state) in enumerate(bfs_path, 1):
        print(f"Step {step_num} - Move: {move} -> State: {state[0]} {state[1]} / {state[2]} {state[3]}")

print("\n--- Running DFS ---")
dfs_path = solve_puzzle_dfs(initial_state)
if isinstance(dfs_path, list):
    print(f"DFS Move count: {len(dfs_path)}")
    for step_num, (move, state) in enumerate(dfs_path, 1):
        print(f"Step {step_num} - Move: {move} -> State: {state[0]} {state[1]} / {state[2]} {state[3]}")







def bfs(edge,names, start):
    visited = []
    discover = []
    
    visited.append(start)
    discover.append(start)
    
    while len(discover) != 0:
        node = discover.pop(0)
        print(names[node])
        
        for neighbor_name in edge[node]:
            neighbor = names.index(neighbor_name)  
            if neighbor not in visited:
                visited.append(neighbor)
                discover.append(neighbor)



def dfs(edge, names, start):
    stack =[]
    visited = []
    
    stack.append(start)
    
    while len(stack) != 0:
        node = stack.pop()
        if node not in visited: 
            visited.append(node)
            print(names[node])
            
            for neighbor_name in edge[node]:
                n = names.index(neighbor_name)
                if n not in visited: 
                    stack.append(n);


def get_solvability(state):
   
    tiles = []
    for x in state:
        if x != 0:
            tiles.append(x)
    
    inv = 0
    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            if tiles[i] > tiles[j]:
                inv += 1
    
    blank_index = state.index(0)
    if blank_index == 0 or blank_index == 1:
        row_from_bottom = 2  
    else:
        row_from_bottom = 1   
    
    return (inv + row_from_bottom) % 2 == 1


def get_neighbors(state):
    blank = state.index(0)
    
    moves_by_position = {
        0: [("Down", 2), ("Right", 1)],
        1: [("Down", 3), ("Left", 0)],
        2: [("Up", 0), ("Right", 3)],
        3: [("Up", 1), ("Left", 2)]
    }
    
    neighbors = []
    for move_name, swap_index in moves_by_position[blank]:
        new_state = list(state)
        new_state[blank], new_state[swap_index] = new_state[swap_index], new_state[blank]
        neighbors.append((tuple(new_state), move_name))
    
    return neighbors

def print_state(state):
    print(state[0], state[1])
    print(state[2], state[3])


def BFS(start, goal):
    visited = []
    queue_list = []          
    queue_list.append((start, [], [start]))
    visited.append(start)
    
    while len(queue_list) != 0:
        current_state, moves_so_far, states_so_far = queue_list.pop(0)   # pop from front
        
        if current_state == goal:
            return moves_so_far, states_so_far
        
        for neighbor_state, move_name in get_neighbors(current_state):
            if neighbor_state not in visited:
                visited.append(neighbor_state)
                new_moves = moves_so_far + [move_name]
                new_states = states_so_far + [neighbor_state]
                queue_list.append((neighbor_state, new_moves, new_states))
    
    return None, None




def DFS(start, goal):
    visited = []
    stack = []
    
    stack.append((start, [], [start]))
    
    while len(stack) != 0:
        current_state, moves_so_far, states_so_far = stack.pop()
        
        if current_state in visited:
            continue
        
        visited.append(current_state)
        
        if current_state == goal:
            return moves_so_far, states_so_far
        
        for neighbor_state, move_name in get_neighbors(current_state):
            if neighbor_state not in visited:
                new_moves = moves_so_far + [move_name]
                new_states = states_so_far + [neighbor_state]
                stack.append((neighbor_state, new_moves, new_states))
    
    return None, None




mapping = ["A", "B", "C", "D", "E", "F"]
edge = [
["B", "C"], # neighbours of A
["A", "D", "E"], # neighbours of B
["A", "F"], # neighbours of C
["B"], # neighbours of D
["B"], # neighbours of E
["C"] # neighbours of F
]
Start = 0
print("BFS visit order: ")
bfs(edge,mapping,Start)

print("DFS visit order: ")
dfs(edge,mapping,Start)




start = (0, 3, 2, 1)
goal = (1, 2, 3, 0)

print("Start:")
print_state(start)
print()
print("Goal:")
print_state(goal)
print()

print("Solvability test...")
if not get_solvability(start):
    print("Not solvable.")
else:
    print("Solvable. Running BFS to find the shortest path...")
    print()
    
    moves, states = BFS(start, goal)
    
    print("Move count:", len(moves))
    print("Solution sequence:")
    print()
    
    print("Step 0:")
    print_state(states[0])
    print()
    
    for i in range(1, len(states)):
        print("Step", i, ":")
        print_state(states[i])
        print("Move:", moves[i - 1])
        print()

    
    print("Running DFS to find a path...")
print()

moves, states = DFS(start, goal)

if moves is None:
    print("No solution found.")
else:
    print("Move count:", len(moves))
    print("Solution sequence:")
    print()
    
    print("Step 0:")
    print_state(states[0])
    print()
    
    for i in range(1, len(states)):
        print("Step", i, ":")
        print_state(states[i])
        print("Move:", moves[i - 1])
        print()
edge = [
["B", "C"], # neighbours of A
["A", "D", "E"], # neighbours of B
["A", "F"], # neighbours of C
["B"], # neighbours of D
["B"], # neighbours of E
["C"] # neighbours of F
]

nodes = ["A","B", "C", "D", "E", "F"]

def bfs(edge, nodes, start):
    visited = []
    q = []
    
    visited.append(start)
    q.append(start)

    
    for n in nodes:
        if all(x in visited for x in nodes):
            return visited
        
        for i in edge[nodes.index(q[0])]:
            
            if(i not in visited):
                q.append(i)
                visited.append(i)
                
        q.pop(0)
        
    return visited



def dfs(edge, nodes, start):
    visited = []
    stack = []
    
    visited.append(start)
    stack.append(start)

    
    while stack:
        found  = False
        for i in edge[nodes.index(stack[-1])]:         
            if(i not in visited):
                stack.append(i)
                visited.append(i)
                found = True
                break
            
        if not found:
            stack.pop()

       
    return visited

# print(bfs(edge, nodes, "A"))
# print(dfs(edge, nodes, "A"))

def print_board(state):
    print(state[0], state[1])
    print(state[2], state[3])

start = (0, 3, 2, 1)
goal = (1, 2, 3, 0)

def get_neighbors(state):

    neighbors = []

    blank = state.index(0)

    # Right
    if blank != 1 and blank != 3:
        new_pos = blank + 1

        new_state = list(state)
        new_state[blank], new_state[new_pos] = new_state[new_pos], new_state[blank]
        new_state = tuple(new_state)

        neighbors.append((new_state, "Right"))

    # Left
    if blank != 0 and blank != 2:
        new_pos = blank - 1

        new_state = list(state)
        new_state[blank], new_state[new_pos] = new_state[new_pos], new_state[blank]
        new_state = tuple(new_state)

        neighbors.append((new_state, "Left"))

    # Up
    if blank != 0 and blank != 1:
        new_pos = blank - 2

        new_state = list(state)
        new_state[blank], new_state[new_pos] = new_state[new_pos], new_state[blank]
        new_state = tuple(new_state)

        neighbors.append((new_state, "Up"))

    # Down
    if blank != 2 and blank != 3:
        new_pos = blank + 2

        new_state = list(state)
        new_state[blank], new_state[new_pos] = new_state[new_pos], new_state[blank]
        new_state = tuple(new_state)

        neighbors.append((new_state, "Down"))

    return neighbors


def bfs2(start):

    queue = []
    visited = set()

    parent = {}
    move_taken = {}

    queue.append(start)
    visited.add(start)

    while queue:

        current = queue.pop(0)

        if current == goal:

            path = []
            current_state = goal

            while current_state != start:
                path.append((current_state, move_taken[current_state]))
                current_state = parent[current_state]

            path.reverse()

            return path

        for neighbor, move in get_neighbors(current):

            if neighbor not in visited:

                visited.add(neighbor)
                queue.append(neighbor)

                parent[neighbor] = current
                move_taken[neighbor] = move

    return None


def dfs2(start):

    stack = []
    visited = set()

    parent = {}
    move_taken = {}

    stack.append(start)
    visited.add(start)

    while stack:

        current = stack.pop()

        if current == goal:

            path = []
            current_state = goal

            while current_state != start:
                path.append((current_state, move_taken[current_state]))
                current_state = parent[current_state]

            path.reverse()

            return path

        for neighbor, move in get_neighbors(current):

            if neighbor not in visited:

                visited.add(neighbor)
                stack.append(neighbor)

                parent[neighbor] = current
                move_taken[neighbor] = move

    return None


solution = bfs2(start)
print(solution)

solution = dfs2(start)
print(solution)
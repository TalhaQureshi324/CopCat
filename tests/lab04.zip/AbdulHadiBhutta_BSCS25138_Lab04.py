#============================== TASK 1a ==============================
def bfs(edge, start):
    visited = [start]
    queue = [start]
    
    while queue:
        curr = queue.pop(0)
        node_idx = ord(curr) - ord('A')
        
        for neighbour in edge[node_idx]:
            if neighbour not in visited:
                visited.append(neighbour)
                queue.append(neighbour)
    
    return visited

edge = [
["B", "C"],
["A", "D", "E"],
["A", "F"],
["B"],
["B"],
["C"]
]
start = 'A'
print("BFS visit order: ", bfs(edge, start))

#============================== TASK 1b ==============================
def dfs(edge, start):
    visited = []
    stack = [start]
    
    while stack:
        curr = stack.pop()
        
        if curr not in visited:
            visited.append(curr)
            node_idx = ord(curr) - ord('A')
            
            for neighbour in reversed(edge[node_idx]):
                if neighbour not in visited:
                    stack.append(neighbour)
    
    return visited

edge = [
["B", "C"],
["A", "D", "E"],
["A", "F"],
["B"],
["B"],
["C"]

]
start = 'A'
print("DFS visit order: ", dfs(edge, start))

#============================== TASK 2a ==============================
def is_solvable(state):
    flat = [tile for tile in state if tile != 0]
    inversions = 0
    
    for i in range(len(flat)):
        for j in range(i + 1, len(flat)):
            if flat[i] > flat[j]:
                inversions += 1
    
    blank_idx = state.index(0)
    row_from_bottom = 2 if blank_idx < 2 else 1
    return (inversions + row_from_bottom) % 2 == 1

def get_neighbors(state):
    blank_idx = state.index(0)
    neighbors = []
    moves = []
    
    if blank_idx in [2, 3]:
        moves.append(('Up', blank_idx - 2))
        
    if blank_idx in [0, 1]:
        moves.append(('Down', blank_idx + 2))
    
    if blank_idx in [1, 3]:
        moves.append(('Left', blank_idx - 1))
        
    if blank_idx in [0, 2]:
        moves.append(('Right', blank_idx + 1))
        
    for move_name, target_idx in moves:
        new_state = list(state)
        new_state[blank_idx], new_state[target_idx] = new_state[target_idx], new_state[blank_idx]
        neighbors.append((tuple(new_state), move_name))
        
    return neighbors

def solve_4puzzle_bfs(start_state, goal_state = (1, 2, 3, 0)):
    print(f"Start:\n{start_state[0]} {start_state[1]}\n{start_state[2]} {start_state[3]}")
    print(f"Goal:\n{goal_state[0]} {goal_state[1]}\n{goal_state[2]} {goal_state[3]}")
    print("Solvability test...")
    
    if not is_solvable(start_state):
        print("Not Solvable.")
        return None
    
    print("Solvable. Running BFS to find the shortest path...")
    queue = [(start_state, [])]
    visited = {start_state}
    
    while queue:
        curr_state, path = queue.pop(0)
        
        if curr_state == goal_state:
            print(f"Move count: {len(path)}")
            print("Solution sequence:")
            print("Step 0:")
            print(f"{start_state[0]} {start_state[1]}\n{start_state[2]} {start_state[3]}")
            
            curr = start_state
            for step_num, (next_st, move) in enumerate(path, 1):
                print(f"Step {step_num}:")
                print(f"{next_st[0]} {next_st[1]}\n{next_st[2]} {next_st[3]}")
                print(f"Move: {move}")
            
            return path
        
        for neighbor, move in get_neighbors(curr_state):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [(neighbor, move)]))

start_state = (0, 3, 2, 1)
solve_4puzzle_bfs(start_state)

#============================== TASK 2b ==============================
def solve_4puzzle_dfs(start_state, goal_state = (1, 2, 3, 0)):
    if not is_solvable(start_state):
        print("Not Solvable.")
        return None
    
    stack = [(start_state, [])]
    visited = {start_state}
    
    while stack:
        curr_state, path = stack.pop()
        
        if curr_state == goal_state:
            print(f"\nDFS Solution Found! Move count: {len(path)}")
            return path
        
        for neighbor, move in get_neighbors(curr_state):
            if neighbor not in visited:
                visited.add(neighbor)
                stack.append((neighbor, path + [(neighbor, move)]))

start_state = (0, 3, 2, 1)
solve_4puzzle_dfs(start_state)
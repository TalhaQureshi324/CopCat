#task one : 

#task one(a) : breadth first search 
from operator import index


goal = (1, 2 ,3, 0)
#node index function 
def node_index(node: str, edge: list) -> int:
    return ord(node) - ord("A")

#bfs function 
def bfs_graph(edge: list, start: str) -> list:
    queue = [start]
    visited = {start}
    orderBFS = []
    front = 0
    while front < len(queue):
        node = queue[front]
        front = front + 1
        orderBFS.append(node)
        index = node_index(node, edge)
        for neighbor in edge[index]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return orderBFS

#task one(b) : depth first search 
def dfs_graph(edge: list, start: str) -> list:
    visited = set()
    orderDFS = []
    def dfs(node: str) -> None:
        if node in visited:
            return
        visited.add(node)
        orderDFS.append(node)
        index = node_index(node, edge)
        for neighbor in edge[index]:
            dfs(neighbor)
    dfs(start)
    return orderDFS

#task two : 4-puzzle helpers
#print board function 
def print_board(boardState: tuple) -> None:
    print(f"{boardState[0]} {boardState[1]}")
    print(f"{boardState[2]} {boardState[3]}")

#function to count inversions
def count_inversions(boardState: tuple) -> int:
    tiles = [tile for tile in boardState if tile != 0]
    inversions = 0
    for p in range(len(tiles)):
        for q in range(p + 1, len(tiles)):
            if tiles[p] > tiles[q]:
                inversions = inversions + 1
    return inversions

#function to get blank row from bottom
def blank_row_from_bottom(boardState: tuple) -> int:
    blankIndex = boardState.index(0)
    return 2 if blankIndex < 2 else 1

#function to check if puzzle is solvable
def is_solvable(boardState: tuple) -> bool:
    inversions = count_inversions(boardState)
    row = blank_row_from_bottom(boardState)
    return (inversions + row) % 2 == 1

#function to get blank neighbors
def blank_neighbors(boardState: tuple) -> list:
    blank = boardState.index(0)
    movesArray = []
    if blank >= 2:
        listBoardState = list(boardState)
        listBoardState[blank], listBoardState[blank - 2] = listBoardState[blank - 2], listBoardState[blank]
        movesArray.append((tuple(listBoardState), "up"))
    if blank < 2:
        listBoardState = list(boardState)
        listBoardState[blank], listBoardState[blank + 2] = listBoardState[blank + 2], listBoardState[blank]
        movesArray.append((tuple(listBoardState), "down"))
    if blank % 2 == 1:
        listBoardState = list(boardState)
        listBoardState[blank], listBoardState[blank - 1] = listBoardState[blank - 1], listBoardState[blank]
        movesArray.append((tuple(listBoardState), "left"))
    if blank % 2 == 0 and blank < 3:
        listBoardState = list(boardState)
        listBoardState[blank], listBoardState[blank + 1] = listBoardState[blank + 1], listBoardState[blank]
        movesArray.append((tuple(listBoardState), "right"))
    return movesArray

#function to bfs puzzle
def bfs_puzzle(initialGoal: tuple) -> list | None:
    if initialGoal == goal:
        return [(initialGoal, None)]
    queue = [initialGoal]
    visited = {initialGoal}
    parent = {initialGoal: (None, None)}
    front = 0
    while front < len(queue):
        current = queue[front]
        front = front + 1
        for next, move in blank_neighbors(current):
            if next in visited:
                continue
            visited.add(next)
            parent[next] = (current, move)
            if next == goal:
                path = []
                s = next
                while s is not None:
                    prev, m = parent[s]
                    path.append((s, m))
                    s = prev
                path.reverse()
                return path
            queue.append(next)
    return None

#functin to dfs puzzle
def dfs_puzzle(initialGoal: tuple) -> list | None:
    if initialGoal == goal:
        return [(initialGoal, None)]
    visited = set()
    stack = [(initialGoal, [(initialGoal, None)])]
    while stack:
        current, path = stack.pop()
        if current == goal:
            return path
        if current in visited:
            continue
        visited.add(current)
        for next, move in reversed(blank_neighbors(current)):
            if next not in visited:
                stack.append((next, path + [(next, move)]))
    return None

#function to print puzzle solution
def print_puzzle_solution(initialGoal: tuple, path: list | None, algorithm: str) -> None:
    print("initial state :")
    print_board(initialGoal)
    print("goal state :")
    print_board(goal)
    print("solvability test...")
    if not is_solvable(initialGoal):
        print("not solvable.")
        return
    if algorithm.upper() == "BFS":
        print("solvable. running bfs to find the shortest path...")
    else:
        print("solvable. running dfs to find a path...")
    if path is None:
        print("no path found.")
        return
    print(f"move count : {len(path) - 1}")
    print("solution sequence:")
    for step, (state, move) in enumerate(path):
        print(f"step {step}:")
        print_board(state)
        if move is not None:
            print(f"move : {move}")
        print()

#function to label
def label(i: int) -> str:
    return chr(ord("A") + i)

#function to input graph
def input_graph() -> tuple[list, str]:
    while True:
        try:
            n = int(input("number of nodes : ").strip())
            if n < 1:
                raise ValueError
            break
        except ValueError:
            print("enter a positive integer.")
    edge = []
    print("enter neighbors for each node.")
    for node in range(n):
        line = input(f"neighbors of {label(node)}: ").strip()
        if line:
            edge.append(line.upper().split())
        else:
            edge.append([])
    start = input("start node : ").strip().upper()
    return edge, start

#function to check graph labels before bfs/dfs
def graph_input_ok(edge: list, start: str) -> bool:
    n = len(edge)
    nodes = {label(i) for i in range(n)}
    if start not in nodes:
        print("error: invalid start node. use a letter such as a (not a number).")
        return False
    for i in range(n):
        for nb in edge[i]:
            if nb not in nodes:
                print(
                    "error: invalid neighbor '" + nb + "'. use letters "
                    + label(0).lower() + "-" + label(n - 1).lower() + " only."
                )
                return False
    return True

#function to input puzzle state
def input_puzzle_state() -> tuple:
    while True:
        raw = input("initial state : ").strip()
        parts = raw.replace(",", " ").split()
        if len(parts) != 4:
            print("need exactly 4 numbers.")
            continue
        try:
            state = tuple(int(x) for x in parts)
        except ValueError:
            print("use integers 0-3 only.")
            continue
        if sorted(state) != [0, 1, 2, 3]:
            print("must use tiles 0, 1, 2, 3 exactly once.")
            continue
        return state

#function to run graph interactive
def run_graph_interactive() -> None:
    print("task 1: graph bfs & dfs")
    edge, start = input_graph()
    if not graph_input_ok(edge, start):
        return
    print("bfs visit order :", bfs_graph(edge, start))
    print("dfs visit order :", dfs_graph(edge, start))


#function to run puzzle interactive
def run_puzzle_interactive() -> None:
    print("task 2: 4-puzzle")
    initial = input_puzzle_state()
    choice = input("solver : bfs, dfs, or both? [bfs/dfs/both]: ").strip().lower()
    if choice in ("bfs", "both", ""):
        print("bfs")
        print_puzzle_solution(initial, bfs_puzzle(initial), "BFS")
    if choice in ("dfs", "both"):
        print("dfs")
        print_puzzle_solution(initial, dfs_puzzle(initial), "dfs")


#function to print menu
def print_menu() -> None:
    print("lab 04 menu :")
    print("1. task 1: graph bfs & dfs")
    print("2. task 2: 4-puzzle")
    print("0. exit")

#function to main
def main() -> None:
    while True:
        print_menu()
        choice = input("enter choice : ").strip()
        if choice == "1":
            run_graph_interactive()
        elif choice == "2":
            run_puzzle_interactive()
        elif choice == "0":
            print("exiting program.")
            break
        else:
            print("invalid choice.")

if __name__ == "__main__":
    main()

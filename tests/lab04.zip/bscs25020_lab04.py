
def bfs(nodes, edge, start):
    visited=[start]
    myqueue=[start]
    
    while myqueue:
        current=myqueue.pop(0)
        idx=nodes.index(current) 
        for n in edge[idx]:
            if n not in visited:
                visited.append(n)  
                myqueue.append(n)
                
    return visited

def dfs(nodes, edge, start):
    visited = []
    def traverse(current):
        visited.append(current)
        idx = nodes.index(current)
        for n in edge[idx]:
            if n not in visited:
                traverse(n)
                
    traverse(start)
    return visited

nodes = ["A", "B", "C", "D", "E", "F"]

edge = [
    ["B", "C"],        # neighbours of A (index 0)
    ["A", "D", "E"],   # neighbours of B (index 1)
    ["A", "F"],        # neighbours of C (index 2)
    ["B"],             # neighbours of D (index 3)
    ["B"],             # neighbours of E (index 4)
    ["C"]              # neighbours of F (index 5)
]

start_node = "A"

bfs_result = bfs(nodes, edge, start_node)
dfs_result = dfs(nodes, edge, start_node)
   
print("BFS visit order:", bfs_result)
print("DFS visit order:", dfs_result)

def is_solvable(state):
    tiles = [x for x in state if x != 0]
    inv = 0
    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            if tiles[i] > tiles[j]:
                inv += 1

    blank_idx = state.index(0)
    row_from_bottom = 2 if blank_idx in (0, 1) else 1
    
    return (inv + row_from_bottom) % 2 == 1


def get_neighbors(state):
    blank_idx = state.index(0)
    neighbors = []
  
    moves = []
    if blank_idx in (2, 3): 
        moves.append(('Up', blank_idx - 2))
    if blank_idx in (0, 1): 
        moves.append(('Down', blank_idx + 2))
    if blank_idx in (1, 3): 
        moves.append(('Left', blank_idx - 1))
    if blank_idx in (0, 2):  
        moves.append(('Right', blank_idx + 1))
        
    for move, new_idx in moves:
        state_list = list(state)
        state_list[blank_idx], state_list[new_idx] = state_list[new_idx], state_list[blank_idx]
        neighbors.append((tuple(state_list), move))
        
    return neighbors


def print_board(state):
    print(f"{state[0]} {state[1]}\n{state[2]} {state[3]}")

def solve_puzzle_bfs(initial_state, goal_state=(1, 2, 3, 0)):
    if not is_solvable(initial_state):
        print("State is NOT solvable.")
        return None
        
    print("Solvable. Running BFS to find the shortest path...")
    queue = [(initial_state, [])]
    visited = {initial_state}
    
    while queue:
        current, path = queue.pop(0)
        if current == goal_state:
            return path
        for next_state, move in get_neighbors(current):
            if next_state not in visited:
                visited.add(next_state)
                queue.append((next_state, path + [(move, next_state)]))
                
    return None

def solve_puzzle_dfs(initial_state, goal_state=(1, 2, 3, 0), max_depth=20):
    if not is_solvable(initial_state):
        print("State is NOT solvable.")
        return None
        
    print("Solvable. Running DFS to find a solution path...")
    stack = [(initial_state, [], [initial_state])]
    
    while stack:
        current, path, visited_path = stack.pop()
        
        if current == goal_state:
            return path
            
        if len(path) < max_depth:
            for next_state, move in reversed(get_neighbors(current)):
                if next_state not in visited_path:
                    stack.append((next_state, path + [(move, next_state)], visited_path + [next_state]))
                
    return None


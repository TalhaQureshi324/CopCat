
def bfs(nodes, edge, start):
    result = []
    q = [start]
    
    while q:
        i = q.pop(0) 
        
        if i not in result:
            result.append(i)
            
        idx = -1
        for j in range(len(nodes)):
            if nodes[j] == i:
                idx = j
                break

        
        for n in edge[idx]:
            if n not in result and n not in q:
                    q.append(n)
            
            
    return result     

def dfs(nodes, edge, start):
    result = []
    stack = [start]
    
    while stack:
        i = stack.pop()

        if i not in result:
            result.append(i)

            idx = -1
            for j in range(len(nodes)):
                if nodes[j] == i:
                    idx = j
                    break

            for n in edge[idx]:
                if n not in result:
                    stack.append(n)
            
            
    return result   
            

nodes = ["A", "B", "C", "D", "E", "F"]

edge = [
["B", "C"], # neighbours of A
["A", "D", "E"], # neighbours of B
["A", "F"], # neighbours of C
["B"], # neighbours of D
["B"], # neighbours of E
["C"] # neighbours of F
]

start = "A"

print("BFS visit order:", bfs(nodes, edge, start))
print("DFS visit order:", dfs(nodes, edge, start))





